from pyEngine import *
import json


GRAVITY = 25.0
MAX_GRAVITY = 100.0

def HandleKeyEvents(engine, keyEvents):
    # Need to fix this later
    for key in keyEvents:
        velX, velY = main_character.GetVelocity()
        if (int(key.symbol)) > 127:
            continue
        if key.eventType == "KEYDOWN":
            if chr(int(key.symbol)) == "a":
                # move main character left
                engine.PlaySound("Assets/sounds/jump.wav")
                engine.UpdateGeneralDisplayNumeric("scoreDisplay", 50)
                main_character.UpdateVelocity(-100.0, velY)
            elif chr(int(key.symbol)) == 'w':
                # move up
                engine.PlaySound("Assets/sounds/jump.wav")
                engine.UpdateGeneralDisplayNumeric("hpDisplay", 50)
                main_character.UpdateVelocity(velX, -300.0)
            elif chr(int(key.symbol)) == 'd':
                # move right
                main_character.UpdateVelocity(100.0, velY)
            # elif chr(int(key.symbol)) == 's':
            #     main_character.UpdateVelocity(None, 100.0)
        elif key.eventType == "KEYUP":
            if chr(int(key.symbol)) == 'a':
                # stop moving left
                main_character.UpdateVelocity(0.0, velY)
            elif chr(int(key.symbol)) == 'w':
                # stop moving up
                main_character.UpdateVelocity(velX, 0.0)
            elif chr(int(key.symbol)) == 'd':
                # stop moving right
                main_character.UpdateVelocity(0.0, velY)
            # elif chr(int(key.symbol)) == 's':
            #     main_character.UpdateVelocity(None, 0.0)

def HandleCollisions(engine, collisions):
    for collision in collisions:
        if collision.entityName2 == "tile":
            mainPosX, mainPosY = engine.entityMap[collision.entityId1].GetPosition()
            mainVelX, mainVelY = engine.entityMap[collision.entityId1].GetVelocity()
            mainWidth, mainHeight = engine.entityMap[collision.entityId1].GetDimensions()
            # tilePosX, tilePosY = engine.entityMap[collision.entityId2].GetPosition()
            # tileWidth, tileHeight = engine.entityMap[collision.entityId2].GetDimensions()

            # Should use the above commented out lines when the tile map is being loaded in python
            # Short circuiting with below because tilemap is being loaded in c++ for the time being
            tilePosX = engine.engine.GetTransformComponent(collision.entityId2).position.x
            tilePosY = engine.engine.GetTransformComponent(collision.entityId2).position.y
            tileWidth = engine.engine.GetStaticCollisionComponent(collision.entityId2).width
            tileHeight = engine.engine.GetStaticCollisionComponent(collision.entityId2).width

            print("Main: " + str(mainPosX) + ", " + str(mainPosY) + ": " + str(mainWidth) + ", " + str(mainHeight))
            print("Tile: " +  str(tilePosX) + ", " + str(tilePosY) + ": " + str(tileWidth) + ", " + str(tileHeight))

            if collision.type == collision.collisionType.top:
                engine.entityMap[collision.entityId1].UpdatePosition(mainPosX, tilePosY - mainHeight)
                engine.entityMap[collision.entityId1].UpdateVelocity(mainVelX, min(0, mainVelY))



def ApplyGravity(gravityEntities):
    for entity in gravityEntities:
        velX, velY = entity.GetVelocity()
        newVelY = min(velY + GRAVITY, MAX_GRAVITY)
        entity.UpdateVelocity(velX, newVelY)


def main():
    engine = Engine()

    resource_manager = ResourceManager(engine)
    resource_manager.AddTexture("dino-image", "./Assets/images/newSprite.png")
    resource_manager.AddTexture("goomba-image", "./Assets/images/goomba.png")
    



    global main_character 
    main_character = GameEntity(engine, "main")
    main_character.AddTransformComponent((0.0, 0.0), (1.0, 1.0), 0.0)
    main_character.AddSpriteComponent("dino-image", 24, 24, 1, 0, 0)
    main_character.AddPhysicsComponent((0.0, 0.0))
    main_character.AddAnimationComponent(13, 10, True)
    main_character.AddCollisionComponent(24, 24, (0.0, 0.0))

    goomba = GameEntity(engine, "goomba")
    goomba.AddTransformComponent((50.0, 50.0), (0.1, 0.1), 0.0)
    goomba.AddSpriteComponent("goomba-image", 300, 300, 1, 0, 0)
    goomba.AddCollisionComponent(30, 30, (0.0, 0.0))
    goomba.AddPhysicsComponent((0.0, 0.0))

    gravityEntities = [main_character, goomba]

    # load tile map image and tile map
    engine.LoadTileMapImage("./Assets/images/Tileset.png")
    # engine.LoadTileMap("./config/TestMap.txt", 1920, 640, 960)

    with open('./config/tileMap.json') as f:
        data1 = json.load(f)

    for data in data1:
        xPos=data['X']
        yPos=data['Y']
        tile=data['TileNumber']
        collider=data['Collide']
        engine.createTileComponents(1920,640,960,xPos,yPos,collider,tile)
        # engine.createTileComponents(1920,640,960)
    

        # print(x['AI'])
        # break
    
    engine.engine.bgImagePath = "Assets/images/snow.png"

    engine.AddGeneralDisplay("scoreDisplay", "./Assets/fonts/DejaVuSansMono.ttf", 0, 0, 50, 200, 234,84,85, "Score: ", 0)
    engine.AddGeneralDisplay("hpDisplay" , "./Assets/fonts/DejaVuSansMono.ttf", 500, 0, 50, 200, 152,150,241, "Lives: ", 3)
    while engine.engine.isRunning:
        engine.PlayMusic("Assets/sounds/BGM-PinnaParkBeach.wav")

        engine.ProcessInput()

        keyEvents = engine.GetKeyBoardInputs()
        collisions = engine.GetCollisions()
        HandleKeyEvents(engine, keyEvents)
        ApplyGravity(gravityEntities)
        HandleCollisions(engine, collisions)
        engine.ClearEvents()

        

        engine.Update()
        engine.Render()



main() 