#!/bin/zsh
export PYTHONPATH=.
./bin/start