# Import C++ Engine
import engine

from collections import defaultdict

class Engine:
    def __init__(self, windowWidth=960, windowHeight=640):
        self.engine = engine.Engine()
        self.engine.Initialize(windowWidth, windowHeight)
        self.entityMap = {}
        self.entityPool = defaultdict(lambda: [])

    def MapEntity(self, entity):
        self.entityMap[entity.id] = entity
        self.entityPool[entity.name].append(entity)

    def CreateEntity(self, name):
        entityId = self.engine.CreateEntity(name)
        return entityId

    def RemoveEntity(self, entity):
        if not entity:
            return
        self.engine.RemoveEntity(entity.id)
        self.entityPool[entity.name].remove(entity)
        self.entityMap[entity.id] = None

    def ProcessInput(self):
        self.engine.ProcessInput()

    def GetKeyBoardInputs(self):
        keyPresses = self.engine.GetKeyBoardInputs()
        return keyPresses

    def GetCollisions(self):
        collisions = self.engine.GetCollisions()
        return collisions

    def ClearEvents(self):
        self.engine.ClearEvents()

    def Update(self):
        self.engine.Update()

    def Render(self):
        self.engine.Render()

    def Run(self):
        while self.engine.isRunning:
            self.ProcessInput()
            self.Update()
            self.Render()
    
    def LoadTileMapImage(self, filePath):
        self.engine.LoadTileMapImage(filePath)
    
    def LoadTileMap(self, filePath, mapWidth, mapHeight, tileMapWidth):
        self.engine.LoadTileMap(filePath, mapWidth, mapHeight, tileMapWidth)
    
    def AddGeneralDisplay(self,ID, fontFilePath, xPos, yPos, height, width, r, g, b, text, numeric = -1):
        self.engine.AddGeneralDisplay(ID,fontFilePath, xPos, yPos, height, width, r, g, b, text, numeric)
    
    def UpdateGeneralDisplayNumeric(self, ID, newVal):
        self.engine.UpdateGeneralDisplayNumeric(ID, newVal)

    def PlayMusic(self, filePath):
        self.engine.PlayMusic(filePath)

    def PlaySound(self, filePath):
        self.engine.PlaySound(filePath)

    def createTileComponents(self,mapWidth,mapHeight,tileMapWidth,x,y,Collision,type1):
        
        self.engine.generateTileComponents(mapWidth,mapHeight,tileMapWidth,x,y,Collision,type1)


class ResourceManager:
    def __init__(self, game_engine):
        self.game_engine = game_engine

    def AddTexture(self, assetId, filePath):
        self.game_engine.engine.AddTexture(assetId, filePath)

class GameEntity:
    def __init__(self, game_engine, name=""):
        self.game_engine = game_engine
        self.name = name
        self.id =  self.game_engine.CreateEntity(name)
        game_engine.MapEntity(self)
        self.static = True

    def AddTransformComponent(self, position=(0.0, 0.0), scale=(1.0, 1.0), rotation=0.0):

        self.game_engine.engine.AddTransformComponent(self.id, 
                                          engine.Vector2D(position[0], position[1]), 
                                          engine.Vector2D(scale[0], scale[1]),
                                          rotation)


    def AddSpriteComponent(self, assetId, width, height, zIndex=0, srcX=0.0, srcY=0.0):
        self.game_engine.engine.AddSpriteComponent(self.id, assetId, width, height, zIndex, srcX, srcY)

    def RemoveSpriteComponent(self):
        self.game_engine.engine.RemoveSpriteComponent(self.id)

    def AddPhysicsComponent(self, velocity=(0.0, 0.0)):
        self.game_engine.engine.AddPhysicsComponent(self.id, engine.Vector2D(velocity[0], velocity[1]))
    
    def RemovePhysicsComponent(self):
        self.game_engine.engine.RemovePhysicsComponent(self.id)

    def AddAnimationComponent(self, numFrames = 1, frameSpeedRate = 1, isLoop = True):
        self.game_engine.engine.AddAnimationComponent(self.id, numFrames, frameSpeedRate, isLoop)

    def AddCollisionComponent(self, width = 0, height = 0, offset = (0.0, 0.0), moving=True):
        self.game_engine.engine.AddCollisionComponent(self.id, width, height, engine.Vector2D(offset[0], offset[1]), moving)
        if moving:
            self.static = False
        else:
            self.static = True

    def RemoveCollisionComponent(self):
        self.game_engine.engine.RemoveCollisionComponent(self.id)

    def AddCameraComponent(self, cameraWidth, cameraHeight, mapWidth, mapHeight):
        self.game_engine.engine.AddCameraComponent(self.id, cameraWidth, cameraHeight, mapWidth, mapHeight)

    def UpdateVelocity(self, velX, velY):
        physics = self.GetComponent("PhysicsComponent")
        physics.velocity.x = velX
        physics.velocity.y = velY

    def GetVelocity(self):
        physics = self.GetComponent("PhysicsComponent")
        return physics.velocity.x, physics.velocity.y

    def UpdatePosition(self, posX, posY):
        transform = self.GetComponent("TransformComponent")
        transform.position.x = posX
        transform.position.y = posY

    def GetPosition(self):
        transform = self.GetComponent("TransformComponent")

        return transform.position.x, transform.position.y

    def GetDimensions(self):
        collision = self.GetComponent("CollisionComponent")

        return collision.width, collision.height

    def GetComponent(self, name):
        if name == "PhysicsComponent":
            return self.game_engine.engine.GetPhysicsComponent(self.id)
        elif name == "TransformComponent":
            return self.game_engine.engine.GetTransformComponent(self.id)
        elif name == "CollisionComponent":
            if not self.static:
                return self.game_engine.engine.GetCollisionComponent(self.id)
            else:
                return self.game_engine.engine.GetStaticCollisionComponent(self.id)



KeyCodes = {
    # https://www.freepascal-meets-sdl.net/sdl-2-0-key-code-lookup-table/ -> SDL_KEYCODES
}