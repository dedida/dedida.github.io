/*
 *  @file   Engine.h
 *  @brief  Engine class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include <fstream>
#include <math.h>
#include <memory>
#include <typeindex>
#include <string>

#include <SDL2/SDL.h>

#include "Constants.h"
#include "TinyMath.hpp"
#include "ECSManager.h"
#include "ResourceManager.h"
#include "EventBus.h"
// Entities
#include "Entity.h"
// Components
#include "PhysicsComponent.h"
#include "TransformComponent.h"
#include "SpriteComponent.h"
#include "CameraComponent.h"
// Systems
#include "RenderSystem.h"
#include "MovementSystem.h"
#include "AnimationSystem.h"
#include "CollisionSystem.h"
#include "CameraFollowSystem.h"
// Events
#include "Event.h"
#include "KeyBoardEvent.h"
#include "CollisionEvent.h"
// Other
#include "GeneralDisplay.h"
using GeneralDisplayPtr = std::shared_ptr<GeneralDisplay>;

/**
 * The engine is where the ecsManager, resourceManager, and eventBus are house. It is where entities and components are created and added as well. It also has the main game loop and is where the rendering and updates are called. 
 */
class Engine
{
private:
    /**
    * Int for SDLTicks, initially set to 0
    */
    int millisecondsLastFrame = 0;
    /**
    * Pointer to window
    */
    SDL_Window *window;
    /**
    * Pointer to renderer
    */
    SDL_Renderer *renderer;
    /**
    * Shared pointer to ecsManager
    */
    std::shared_ptr<ECSManager> ecsManager;
    /**
    * Shared pointer to resourceManager
    */
    std::unique_ptr<ResourceManager> resourceManager;
    /**
    * Shared pointer to eventBus
    */
    std::unique_ptr<EventBus> eventBus;
    /** 
    * SDL_Rect representation of the engine's camera
    */
    SDL_Rect camera;

public:
    /**
      * Constructor of class Engine
      */
    Engine();
    ~Engine();
    /**
    * Method used to set default start up values for the fields in the engine
    * @param windowWidth int setting the SDL window width
    * @param windowHeight int setting the SDL window height
    */
    void Initialize(int windowWidth, int windowHeight);
    /**
    * Method used to act as a loop while game is running and call ProcessInput(), Update(), and Render()
    */
    void Run();
    /**
    * Method used to handle keyboard events
    */
    void ProcessInput();
    /**
    * Method used to update values in components via systems in the ecsManagaer
    */
    void Update();
    /**
    * Method used to render game entities in ecsManager and background image
    */
    void Render();
    /**
    * Method used to destroy renderer, window, and quit SDL
    */
    void Destroy();
    /**
    * Method used to create an entity and add it to the resourcemanager
    * @param string name for enttity
    * @return entity ID an int 
    */
    int CreateEntity(std::string name);
    /**
    * Method used to remove an entity based on its ID
    * @param entityId int representing the entity's id to be removed 
    * @return entity ID an int 
    */
    void RemoveEntity(int entityId);
    /**
    * Method used to add texture to resourceManager
    * @param assetId string ID 
    * @param filePath string 
    */
    void AddTexture(std::string assetId, std::string filePath);
    /**
    * Method used to add transform component to an entity
    * @param entityId int
    * @param position Vector2D
    * @param scale Vector2D
    * @param rotation float
    */
    void AddTransformComponent(int entityId, Vector2D position, Vector2D scale, float rotation);
    /**
    * Method used to add a sprite component to an entity 
    * @param entityId int
    * @param assetId string
    * @param w int width
    * @param h int height
    * @param zIndex int 
    * @param srcX int
    * @param srcY int
    */
    void AddSpriteComponent(int entityId, std::string assetId, int w, int h, int zIndex, int srcX, int srcY);
    /**
    * Method used to add a physics component to an entity
    * @param entityId int
    * @param velocity Vector2D
    */
    void AddPhysicsComponent(int entityId, Vector2D velocity);
    /**
    * Method used to add an animation component to an entity 
    * @param entityId int
    * @param numFrames int
    * @param frameSpeedRate int
    * @param isLoop bool
    */
    void AddAnimationComponent(int entityId, int numFrames, int frameSpeedRate, bool isLoop);
    /**
    * Method used to add a collision componenent to an entity
    * @param entityId int
    * @param width int
    * @param height int
    * @param offset Vector2D
    * @param moving bool
    */
    void AddCollisionComponent(int entityId, int width, int height, Vector2D offset, bool moving);
     /**
      * Method used to add a camera componenent to an entity
      * @param entityId int
      * @param cameraWidth int setting the camera's width
      * @param cameraHeight int setting the camera's height
      * @param mapWidth int setting the map's width
      * @param mapHeight int setting the map's height
      */
    void AddCameraComponent(int entityId, int cameraWidth, int cameraHeight, int mapWidth, int mapHeight);
    /**
    * Method used to update a physics componenent to an entity
    * @param entityId int
    * @param newVelocity Vector2D
    */
    void UpdatePhysicsComponent(int entityId, Vector2D newVelocity);
    /**
    * Method used to update a transform componenent to an entity
    * @param entityId int
    * @param newPosition Vector2D
    */
    void UpdateTransformComponent(int entityId, Vector2D newPosition);
    /**
    * Method used to get a physics component 
    * @param entityId int 
    * @return Physics Component 
    */
    PhysicsComponent &GetPhysicsComponent(int entityId);
    /**
    * Method used to get TransformComponent 
    * @param entityId int
    * @return Transform Component 
    */
    TransformComponent &GetTransformComponent(int entityId);
    /**
    * Method used to get CollisionComponent 
    * @param entityId int
    * @return Collision Component 
    */
    CollisionComponent &GetCollisionComponent(int entityId);
    /**
    * Method used to get StaticCollisionComponent 
    * @param entityId int
    * @return StaticCollision Component 
    */
    StaticCollisionComponent &GetStaticCollisionComponent(int entityId);
    /**
    * Method used to remove SpriteComponent 
    * @param entityId int
    */
    void RemoveSpriteComponent(int entityId);
    /**
    * Method used to remove PhysicsComponent 
    * @param entityId int
    */
    void RemovePhysicsComponent(int entityId);
    /**
    * Method used to remove CollisionComponent 
    * @param entityId int
    */
    void RemoveCollisionComponent(int entityId);
    /**
    * Method used to retrieve keyboard events
    * @return shared pointer to vector of keyboard events
    */
    std::vector<std::shared_ptr<KeyBoardEvent>> GetKeyBoardInputs();
    /**
    * Method used to retrieve collions 
    * @return shared pointer to vector of collisions 
    */
    std::vector<std::shared_ptr<CollisionEvent>> GetCollisions();
    /**
    * Method used to
    */
    void ClearEvents();
    /**
    * Method used to add a general display to the game
    * @param ID to identify general display
    * @param fontFilePath string font file path
    * @param xPos int x location of display
    * @param xPos int y location of display
    * @param height int height of display
    * @param width int width of display
    * @param r int red color value 0 - 255
    * @param g int green color value 0 - 255
    * @param b int blue color value 0 - 255
    * @param text string text to be displayed
    * @param numeric number to be displayer (optional)
    */
    void AddGeneralDisplay(std::string ID, std::string fontFilePath, int xPos, int yPos, int height, int width, int r, int g, int b, std::string text, int numeric = -1);
    /**
    * Method used to update general display numeric value
    * @param ID string to select display to update
    * @param newVal int new number to update with
    */
    void UpdateGeneralDisplayNumeric(std::string ID, int newVal);
    /** 
    * Method used to load music if it is not yet loaded into resourceManager and play music
    * @param filePath string file path for music
    */
    void PlayMusic(std::string filePath);
    /**
    * Method used to load sound if it is not yet loaded into resourceManager and play sound
    * @param filePath string file path for sound
    */
    void PlaySound(std::string filePath);
    /**
    * Method used to load tile map source image
    * @param filePath string file path for image
    */
    void LoadTileMapImage(std::string filePath);
    /**
    * Method used to load Tile Map into the game
    * @param mapFilepath string file path for tile txt file
    * @param mapWidth int map width size
    * @param mapHeight int map height size
    * @param tileMap int tile size
    */
    void LoadTileMap(std::string mapFilePath, int mapWidth, int mapHeight, int tileMapWidth);
    void generateTileComponents(int mapWidth, int mapHeight, int tileMapWidthint ,int x, int y, bool CollisionComponent, int type);


    /**
    * Bool used to start game loop
    */
    bool isRunning = false;
    /**
    * Int for window width size
    */
    int windowWidth = WINDOW_WIDTH;
    /**
    * Int for window height size
    */
    int windowHeight = WINDOW_HEIGHT;
    /**
    * String for background image file path
    */
    std::string bgImagePath = "none";
    /**
    * Vector used to store general displays for the game
    */
    std::vector<GeneralDisplayPtr> m_general_display;
};

#endif
