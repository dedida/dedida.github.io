/*
 *  @file   EventBus.h
 *  @brief  EventBus class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef EVENTBUS_H
#define EVENTBUS_H

#include <iostream>
#include <map>
#include <memory>
#include <typeindex>
#include <vector>

#include "Event.h"
#include "CollisionEvent.h"
#include "KeyBoardEvent.h"

/**
 * The EventBus is responsible for handling collisions depending on keyboard events/movement within the game
 */
class EventBus
{
private:
public:
    /**
      * Constructor of class EventBus
      */
    EventBus() = default;
    /**
    * shared pointer to vector of keyboard events
    */
    std::vector<std::shared_ptr<KeyBoardEvent>> keyboardEvents;
    /**
    * shared pointer to vector of collision events
    */
    std::vector<std::shared_ptr<CollisionEvent>> collisionEvents;
    /**
    * Method used to clear all events 
    */
    void ClearEvents();
    /**
    * Add keyboard event to keyboard events vector
    * @param event KeyBoardEvent
    */
    void PublishKeyBoardEvent(KeyBoardEvent &event);
    /**
    * Add collison to collision events vector
    * @param event CollisionEvent 
    */
    void PublishCollisionEvent(CollisionEvent &event);
};

//// OLD IMPLEMENTATION BELOW

// class EventBus {
//     private:
//         std::map<std::type_index, std::vector<std::type_index>> subscribers;
//     public:
//         EventBus() = default;
//         std::map<std::type_index, std::vector<std::shared_ptr<Event>>> eventMap;
//         template <typename TClass, typename TEvent> void Subscribe(TEvent& event);
//         template <typename TEvent> void Publish(TEvent& event);
// };

// //////////////////////////////////////////////////////////////////////////////////////////
// // Template function definitions below
// ////////////////////////////////////////////////////////////////////////////////////////////

// template <typename TClass, typename TEvent>
// void EventBus::Subscribe(TEvent& event) {
//     if (subscribers.find(typeid(TEvent)) == subscribers.end()) {
//         subscribers[typeid(TEvent)] = std::vector<std::type_index>();
//     }

//     std::vector<std::type_index> subscriberList = subscribers[typeid(TEvent)];

//     subscriberList.push_back(typeid(event));
// }

// template <typename TEvent>
// void EventBus::Publish(TEvent& event) {
//     for (auto it = subscribers.begin(); it != subscribers.end(); it++) {
//         for (auto id : it->second) {
//             if (id == typeid(event)) {

//                 if (eventMap.find(typeid(it->first)) == eventMap.end()){
//                     eventMap[typeid(it->first)] = std::vector<std::shared_ptr<Event>>();
//                 }
//                 std::vector<std::shared_ptr<Event>> eventMapList = eventMap[typeid(it->first)];

//                 eventMapList.push_back(std::make_shared<Event>(event));
//             }
//         }
//     }
// }

#endif