/*
 *  @file   Component.h
 *  @brief  Component class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef COMPONENT_H
#define COMPONENT_H

/**
 * Base component that stores the ID of the component  
 */
struct BaseComponent
{
protected:
    static int nextId;
};

/**
 * Template component used to hold data for different aspects of a game entity 
 */
template <typename T>
class Component : public BaseComponent
{
private:
public:
    static int GetId()
    {
        static auto id = nextId++;
        return id;
    }
};

#endif
