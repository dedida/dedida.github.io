/*
 *  @file   Event.h
 *  @brief  Event class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef EVENT_H
#define EVENT_H

class Event
{
public:
    virtual ~Event() = default;
};

#endif