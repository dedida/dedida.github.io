#ifndef KEYBOARDEVENT_H
#define KEYBOARDEVENT_H
/*
 *  @file   KeyBoardEvent.h
 *  @brief  KeyBoardEvent class interface 
 *  @date   2021-04-22
 ***********************************************/
#include <SDL2/SDL.h>

#include <string>

#include "Event.h"

/**
    *  KeyBoardEvent class is used to manage keybindings
    */
class KeyBoardEvent
{
public:
    /**
    *  string used as symbol/key used
    */
    std::string symbol;
    /**
    *  string used to specify event type
    */
    std::string eventType;

    /**
      * Constructor of class KeyBoardEvent
      */
    KeyBoardEvent() = default;

    KeyBoardEvent(SDL_Event event)
    {
        this->symbol = std::to_string(event.key.keysym.sym); // keycode
        if (event.type == SDL_KEYUP)
        {
            this->eventType = "KEYUP";
        }
        else if (event.type == SDL_KEYDOWN)
        {
            this->eventType = "KEYDOWN";
        }
    };
};

#endif