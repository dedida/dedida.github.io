/*
 *  @file   CollisionEvent.h
 *  @brief  CollisionEvent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef COLLISIONEVENT_H
#define COLLISIONEVENT_H

#include <string>

#include "Entity.h"
#include "Event.h"

/**
    *  Class that encompasses the collision that happens between two entities
    */
class CollisionEvent
{
public:
    /**
    *  enum used to label collision types
    */
    enum collisionType
    {
        top,
        right,
        bottom,
        left
    };
    /**
    *  int entityId1 identifier for entity 1
    */
    int entityId1;
    /**
    *  string entityName1 identifier
    */
    std::string entityName1;
    /**
    *  int entityId2 identifier for entity 2
    */
    int entityId2;
    /**
    *  string entityName2 identifier
    */
    std::string entityName2;
    /**
    *  collision type
    */
    collisionType type;

    /**
      * Constructor of class CollisionEvent
      */
    CollisionEvent() = default;
    CollisionEvent(int entityId1, std::string entityName1, int entityId2, std::string entityName2, collisionType collision = collisionType::top)
    {
        this->entityId1 = entityId1;
        this->entityName1 = entityName1;
        this->entityId2 = entityId2;
        this->entityName2 = entityName2;
        this->type = collision;
    }
};

#endif