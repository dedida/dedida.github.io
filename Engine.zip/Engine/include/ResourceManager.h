/*
 *  @file   ResourceManager.h
 *  @brief  ResourceManager class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef RESOURCEMANAGER_H
#define RESOURCEMANAGER_H

#include <iostream>
#include <map>
#include <string>

#include <SDL2/SDL.h>
#include <SDL2_image/SDL_image.h>
#include <SDL2_mixer/SDL_mixer.h>
#include <SDL2_ttf/SDL_ttf.h>
/**
 * The resource manager is responsible for handling and managing resources regarding the game
 */
class ResourceManager
{
private:
  std::map<std::string, SDL_Texture *> textures;
  /**
    * Hashmap used to keep track of Images where path to image is key and its Spritesheet is value
    */
  std::map<std::string, SDL_Texture *> textureMap;
  /**
    * Hashmap used to keep track of fonts where path to font is key and its TTF_Font class is value
    */
  std::map<std::string, TTF_Font *> fontMap;

  /**
    * Hashmap used to keep track of musics where path to music is key and its Mix_Music class is value
    */
  std::map<std::string, Mix_Music *> soundMap;

  /**
      * * Hashmap used to keep track of musics where path to sound effect is key and its Mix_Chunk class is value
    */
  std::map<std::string, Mix_Chunk *> soundEffectMap;

public:
  /**
      * Constructor of class Resource Manager
      */
  ResourceManager();
  ~ResourceManager();
  void ClearAssets();
  void AddTexture(SDL_Renderer *renderer, const std::string &assetId, const std::string &filePath);
  SDL_Texture *GetTexture(const std::string &assetId);
  SDL_Texture *loadTexture(std::string filePath, SDL_Renderer *renderer);
  /**
    * Method used to load TTF_Font object of respective font from its path
    * @param filePath path where font is stored
    * @return TTF_Font object of respective font
    */
  TTF_Font *loadFont(std::string filePath, int fontSize);
  /**
    * Method used to load Mix_Music object of respective music from its path
    * @param filePath path where music is stored
    * @return Mix_Music object of respective music
    */
  Mix_Music *loadMusic(std::string filePath);
  /**
    * Method used to load Mix_Chunk object of respective music from its path
    * @param filePath path where music is stored
    * @return Mix_Chunk object of respective music
    */
  Mix_Chunk *loadWAV(std::string filePath);
};

#endif
