/*
 *  @file   RenderSystem.h
 *  @brief  RenderSystem class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef RENDERSYSTEM_H
#define RENDERSYSTEM_H

#include <vector>

#include <SDL2/SDL.h>

#include "ECSManager.h"
#include "ResourceManager.h"
#include "TransformComponent.h"
#include "SpriteComponent.h"
#include "Entity.h"
#include "System.h"

/**
 * The RenderSystem is responsible for updating components that dealt with graphics
 */
class RenderSystem : public System
{
public:
    /**
      * Constructor of class RenderSystem
      */
    RenderSystem()
    {
        RequireComponent<TransformComponent>();
        RequireComponent<SpriteComponent>();
    }
    /**
    * Method used to update graphics related components
    * @param renderer pointer to SDL_renderer
    * @param ecsManager shared pointer to ECSManager
    * @param resourceManager unique pointer to ResourceManager
    * @param camera reference to SDL_Rect
    */
    void Update(SDL_Renderer *renderer, std::shared_ptr<ECSManager> &ecsManager, std::unique_ptr<ResourceManager> &resourceManager, SDL_Rect& camera);
};

#endif