/*
 *  @file   CollisionSystem.h
 *  @brief  CollisionSystem class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef COLLISIONSYSTEM_H
#define COLLISIONSYSTEM_H

#include <memory>

#include "ECSManager.h"
#include "EventBus.h"
#include "StaticCollisionSystem.h"
#include "CollisionEvent.h"
#include "CollisionComponent.h"
#include "StaticCollisionComponent.h"
#include "TransformComponent.h"
#include "PhysicsComponent.h"

/**
 * The CollisionSystem is responsible for updating components that dealt with collisions 
 */
class CollisionSystem : public System
{
public:
    /**
      * Constructor of class CollisionSystem
      */
    CollisionSystem()
    {
        RequireComponent<CollisionComponent>();
        RequireComponent<TransformComponent>();
    }

    /**
    * Method used to update collision related components
    * @param eventBus unique pointer
    * @param ecsManager shared pointer 
    * @param staticCollisionSystem 
    */
    void Update(std::unique_ptr<EventBus> &eventBus, std::shared_ptr<ECSManager> &ecsManager, StaticCollisionSystem &staticCollisionSystem);

    /**
    * Method used to check for collison
    * @param aX float
    * @param aY float
    * @param aW float
    * @param aH float
    * @param bX float
    * @param bY float
    * @param bW float
    * @param bH float
    * @return bool 
    */
    bool CheckAABBCollision(float aX, float aY, float aW, float aH, float bX, float bY, float bW, float bH);

    /**
    * Method used to check collision direction
    * @param aX float
    * @param aY float
    * @param aW float
    * @param aH float
    * @param bX float
    * @param bY float
    * @param bW float
    * @param bH float
    * @return collisionType
    */
    CollisionEvent::collisionType CheckCollisionDirection(float aX, float aY, float aW, float aH, float bX, float bY, float bW, float bH);
};

#endif