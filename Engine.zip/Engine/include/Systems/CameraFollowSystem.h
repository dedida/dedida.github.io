#ifndef CAMERAFOLLOWSYSTEM_H
#define CAMERAFOLLOWSYSTEM_H

#include <SDL2/SDL.h>

#include "CameraComponent.h"
#include "TransformComponent.h"

#include "ECSManager.h"
#include "Entity.h"
#include "System.h"

class CameraFollowSystem : public System {
    public:
        CameraFollowSystem() {
            RequireComponent<CameraComponent>();
            RequireComponent<TransformComponent>();
        }

        void Update(std::shared_ptr<ECSManager> &ecsManager, SDL_Rect& camera);

};

#endif