/*
 *  @file   AnimationSystem.h
 *  @brief  AnimationSystem class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef ANIMATIONSYSTEM_H
#define ANIMATIONSYSTEM_H

#include <memory>
#include <SDL2/SDL.h>

#include "SpriteComponent.h"
#include "AnimationComponent.h"
#include "ECSManager.h"
#include "Entity.h"
#include "System.h"

/**
 * The AnimationSystem is responsible for updating components that dealt with animation
 */
class AnimationSystem : public System
{
public:
    /**
      * Constructor of class AnimationSystem
      */
    AnimationSystem()
    {
        RequireComponent<AnimationComponent>();
        RequireComponent<SpriteComponent>();
    }

    /**
    * Method used to update animation related components
    * @param ecsManager shared pointer 
    */
    void Update(std::shared_ptr<ECSManager> &ecsManager);
};

#endif