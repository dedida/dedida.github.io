/*
 *  @file   MovementSystem.h
 *  @brief  MovementSystem class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef MOVEMENTSYSTEM_H
#define MOVEMENTSYSTEM_H

#include "TransformComponent.h"
#include "PhysicsComponent.h"
#include "Entity.h"
#include "ECSManager.h"
#include "System.h"

/**
 * The MovementSystem is responsible for updating components that dealt with movement
 */
class MovementSystem : public System
{
private:
public:
    /**
      * Constructor of class MovementSystem
      */
    MovementSystem()
    {
        RequireComponent<TransformComponent>();
        RequireComponent<PhysicsComponent>();
    }
    /**
    * Method used to update movement related components
    * @param deltatTime float
    * @param ecsManager shared pointer 
    */
    void Update(float deltaTime, std::shared_ptr<ECSManager> &ecsManager);
};

#endif