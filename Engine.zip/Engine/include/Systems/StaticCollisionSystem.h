/*
 *  @file   StaticCollisionSystem.h
 *  @brief  StaticCollisionSystem class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef STATICCOLLISIONSYSTEM_H
#define STATICCOLLISIONSYSTEM_H

#include "ECSManager.h"
#include "EventBus.h"
#include "CollisionComponent.h"
#include "TransformComponent.h"
#include "StaticCollisionComponent.h"

/**
 *  Dummy System to used to collect non-moving objects in the CollisionSystem
 */
class StaticCollisionSystem : public System
{
public:
    /**
      * Constructor of class StaticCollisionSystem
      */
    StaticCollisionSystem()
    {
        RequireComponent<TransformComponent>();
        RequireComponent<StaticCollisionComponent>();
    }
};

#endif