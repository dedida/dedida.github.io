/*
 *  @file   GeneralDisplay.h
 *  @brief  GeneralDisplay class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef GENERALDISPLAY_H
#define GENERALDISPLAY_H

#include <SDL2/SDL.h>
#include <iostream>

#include "ResourceManager.h"

/**
 * The GeneralDisplay is responsible showing custom text and numbers (optional) during gameplay 
 */
class GeneralDisplay
{
public:
    /**
    * String for ID 
    */
    std::string ID;
    /**
    * SDL_Renderer used to render display
    */
    SDL_Renderer *renderer;
    /**
    * int red color value for text (0-255)
    */
    int r;
    /**
    * int green color value for text (0-255)
    */
    int g;
    /**
    * int blue color value for text (0-255)
    */
    int b;
    /**
    * Text for display 
    */
    std::string text;
    /**
    * Int number for display
    */
    int numeric;
    /**
    * SDL_Surface for display
    */
    SDL_Surface *wordSurface;
    /**
    * SDL_Texture for display
    */
    SDL_Texture *wordTexture;
    /**
    * TTF_Font used to write the text
    */
    TTF_Font *font;
    /**
    * SDL_Rect that the display is rendered to
    */
    SDL_Rect rect1;

    /**
      * Constructor of class General Display
      */
    GeneralDisplay(std::string ID, SDL_Renderer *renderer, TTF_Font *font, int xPos, int yPos, int height, int width, int r, int g, int b, std::string text, int numeric = -1)
    {
        this->ID = ID;
        this->renderer = renderer;
        rect1.x = xPos;
        rect1.y = yPos;
        rect1.w = width;
        rect1.h = height;
        this->r = r;
        this->g = g;
        this->b = b;
        this->text = text;
        this->numeric = numeric;
        this->font = font;

        if (numeric == -1)
        {
            this->wordSurface = TTF_RenderText_Solid(font, text.c_str(), {(uint8_t)r, (uint8_t)g, (uint8_t)b});
            this->wordTexture = SDL_CreateTextureFromSurface(renderer, wordSurface);
        }
        else
        {
            std::string numberIntoText = std::to_string(numeric);
            std::string newString = text + numberIntoText;
            this->wordSurface = TTF_RenderText_Solid(font, newString.c_str(), {(uint8_t)r, (uint8_t)g, (uint8_t)b});
            this->wordTexture = SDL_CreateTextureFromSurface(renderer, wordSurface);
        }
    }
    /**
    * Method used to change number on display
    * @param newNum int 
    */
    void UpdateNumericValue(int newNum)
    {
        std::string numberIntoText = std::to_string(newNum);
        std::string newString = text + numberIntoText;
        this->wordSurface = TTF_RenderText_Solid(font, newString.c_str(), {(uint8_t)r, (uint8_t)g, (uint8_t)b});
        this->wordTexture = SDL_CreateTextureFromSurface(renderer, wordSurface);
    }

    /**
    * Method used to render display
    */
    void Render()
    {
        SDL_RenderCopy(renderer, wordTexture, NULL, &rect1);
    }
};
#endif