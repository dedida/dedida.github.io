/*
 *  @file   Constants.h
 *  @brief  A file to keep track of all the constants
 *  @date   2021-04-22
 ***********************************************/
#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <bitset>

const int FPS = 60;
const int MILLISECONDS_PER_FRAME = 1000 / FPS;
const int WINDOW_WIDTH = 960;
const int WINDOW_HEIGHT = 640;

// Define Signatures
// Used to keep track of which components a system/entity has
const unsigned int MAX_COMPONENTS = 32;
typedef std::bitset<MAX_COMPONENTS> Signature;

//menu stuff
static const std::string MENU_IMAGE = "./Assets/images/menu_image2.png";
const int BUTTON_WIDTH = 320;
const int BUTTON_HEIGHT = 50;
const int BUTTON_X_POS = (WINDOW_WIDTH / 2) - (BUTTON_WIDTH / 2);
const int PLAY_BUTTON_Y_POS = 350; //3 * (WINDOW_HEIGHT / 4);
const int LEVEL_BUTTON_Y_POS = PLAY_BUTTON_Y_POS + 60;
const int SPRITE_BUTTON_Y_POS = LEVEL_BUTTON_Y_POS + 60;
const int QUIT_BUTTON_Y_POS = SPRITE_BUTTON_Y_POS + 60;

#endif