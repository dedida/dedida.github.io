/*
 *  @file   ECSManager.h
 *  @brief  ECSManager class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef ECSMANAGER_H
#define ECSMANAGER_H

#include <deque>
#include <iostream>
#include <memory>
#include <set>
#include <string>
#include <typeindex>
#include <unordered_map>
#include <vector>

#include "Constants.h"
#include "Component.h"
#include "Entity.h"
#include "System.h"

class System;

class IComponentVector
{
public:
    virtual ~IComponentVector(){};
};

/**
* Generic Template wrapper for a vector
*/
template <typename T>
class ComponentVector : public IComponentVector
{
private:
    std::vector<T> data;
public:
    /**
    * Constructor of the class
    */
    ComponentVector(int size = 100)
    {
        data.resize(size);
    }
    /**
    * Virtual Destructor of the class
    */
    virtual ~ComponentVector() = default;
    /**
    * To check if the vector is empty
    * @return a boolean representing empty or full
    */
    bool isEmpty() const
    {
        return data.empty();
    }
    /**
    * Returns the size of vector
    * @return the size the of the vector
    */
    int GetSize() const
    {
        return data.size();
    }
    /**
    * To resize the vector
    */
    void Resize(int n)
    {
        data.resize(n);
    }
    /**
    * Clear the contents of the vector
    */
    void Clear()
    {
        data.clear();
    }
    /**
    * Add an object to the vector
    * @param object an object of type T
    */
    void Add(T object)
    {
        data.push_back(object);
    }
    /**
    * Set an object at a particular index
    * @param index the position to insert the object at
    * @param object the object of type T to be inserted
    */
    void Set(int index, T object)
    {
        data[index] = object;
    }
    /**
    * Returns the object at the particular index
    *  @param index the index number of the object
    * @return object of type T
    */
    T& Get(int index)
    {
        return static_cast<T &>(data[index]);
    }
    /**
    * Operator overloading of [] to get the object at index
    *  @param index the index number of the object
    * @return object of type T
    */
    T &operator[](unsigned int index)
    {
        return data[index];
    }
};

/**
 * The ECSmanager is responsible for handling and managing components within entities
 */
class ECSManager
{
private:
    int numEntities = 0;

    // A vector of component types of vectors
    // Structure example:
    // <TransformComponent> <SpriteComponent> <PhysicsComponent> ...
    //  Entity0 Transform     Entity0 Sprite  NULL (E0 has no PC)
    //     E1 Transform         E1 Sprite         E1 Physics
    // ....
    std::vector<std::shared_ptr<IComponentVector>> componentVectors;

    // A vector containing each entity's component signature
    std::vector<Signature> entityComponentSignatures;

    // A map that uses the type index (created by C++) as key and the specific system as at the value
    std::unordered_map<std::type_index, std::shared_ptr<System>> systems;

    std::set<std::shared_ptr<Entity>> entitiesToBeAdded;
    std::set<std::shared_ptr<Entity>> entitiesToBeKilled;
    std::set<int> entityIdsToBeKilled;

    // Queue of available entity ids that were previously removed
    std::deque<int> freeIds;

public:
    /**
      * Constructor of class Resource Manager
      */
    ECSManager() = default;

    // General ECS functions
    void Update();

    // Entity management

    /**
    * Method used to create an entity 
    * @param name string 
    * @return shared pointer to entity 
    */
    std::shared_ptr<Entity> CreateEntity(std::string name);
    /**
    * Method used to remove entity 
    * @param entity shared pointer 
    */
    void RemoveEntity(std::shared_ptr<Entity> entity);
    /**
    * Method used to remove entity by its ID
    * @param entityId integer 
    */
    void RemoveEntityById(int entityId);
    /**
    * Method used to add entity to system 
    * @param entity shared pointer 
    */
    void AddEntityToSystem(std::shared_ptr<Entity> entity);

    // Component management

    template <typename T, typename... TArgs>
    /**
    * Method used to add component 
    * @param entity shared pointer 
    */
    void AddComponent(std::shared_ptr<Entity> entity, TArgs &&... args);
    template <typename T, typename... TArgs>
    /**
    * Method used to add component by id
    * @param entityId int 
    */
    void AddComponentById(int entityId, TArgs &&... args);
    template <typename T>
    /**
    * Method used to remove component 
    * @param entity shared pointer 
    */
    void RemoveComponent(std::shared_ptr<Entity> entity);
    template <typename T>
    /**
    * Method used to remove component by Id
    * @param entityID
    */
    void RemoveComponentById(int entityId);
    template <typename T>
    /**
    * Method used to check if a component exists 
    * @param entity shared pointer
    * @return bool
    */
    bool HasComponent(std::shared_ptr<Entity> entity);
    template <typename T>
    /**
    * Method used to check if a component exists via ID
    * @param entityId int 
    * @return bool
    */
    bool HasComponentById(int entityId);
    template <typename T>
    /**
    * Method used to get a component 
    * @param entity shared pointer
    * @return reference to a component 
    */
    T &GetComponent(std::shared_ptr<Entity> entity);
    template <typename T>
    /**
    * Method used to get a component 
    * @param entityID int
    * @return component 
    */
    T &GetComponentById(int entityId);

    // System management

    template <typename T, typename... TArgs>
    /**
    * Method used to add a system
    * @param system 
    */
    void AddSystem(TArgs &&... args);
    template <typename T>
    /**
    * Method used to remove a system
    */
    void RemoveSystem();
    template <typename T>
    /**
    * Method used to check if ECSManager has a system
    * @return bool 
    */
    bool HasSystem();
    template <typename T>
    /**
    * Method used to get a system
    * @return reference to system
    */
    T &GetSystem();

    // Checks the component signature of an entity and add the entity to the systems that are interested in it
    void AddEntityToSystems(std::shared_ptr<Entity> entity);
    // Checks the component signature of an entity and removes it from the correct systems interested in it
    void RemoveEntityFromSystems(std::shared_ptr<Entity> entity);
    void RemoveEntityIdFromSystems(int entityId);
};

//////////////////////////////////////////////////////////////////////////////////////////
// Template function definitions below
////////////////////////////////////////////////////////////////////////////////////////////

template <typename T, typename... TArgs>
void ECSManager::AddSystem(TArgs &&... args)
{
    std::shared_ptr<T> newSystem = std::make_shared<T>(std::forward<TArgs>(args)...);
    systems.insert(std::make_pair(std::type_index(typeid(T)), newSystem));
}

template <typename T>
void ECSManager::RemoveSystem()
{
    auto system = systems.find(std::type_index(typeid(T)));
    systems.erase(system);
}

template <typename T>
bool ECSManager::HasSystem()
{
    return systems.find(std::type_index(typeid(T))) != systems.end();
}

template <typename T>
T &ECSManager::GetSystem()
{
    auto system = systems.find(std::type_index(typeid(T)));
    return *std::static_pointer_cast<T>(system->second);
}

template <typename T, typename... TArgs>
void ECSManager::AddComponentById(int entityId, TArgs &&... args)
{
    const auto componentId = Component<T>::GetId();

    if (componentId >= componentVectors.size())
    {
        componentVectors.resize(componentId + 1, nullptr);
    }

    // Check if there is a vector at the location for this component type
    if (!componentVectors[componentId])
    {
        // There is no vector there so create a new one
        std::shared_ptr<ComponentVector<T>> newComponentVector = std::make_shared<ComponentVector<T>>();
        componentVectors[componentId] = newComponentVector;
    }

    std::shared_ptr<ComponentVector<T>> componentVector = std::static_pointer_cast<ComponentVector<T>>(componentVectors[componentId]);

    if (entityId >= componentVector->GetSize())
    {
        componentVector->Resize(numEntities);
    }

    T newComponent(std::forward<TArgs>(args)...);

    // Set component vector at entityId location to have the newComponent
    componentVector->Set(entityId, newComponent);

    // Set signature so that the entity now contains a component of type T
    entityComponentSignatures[entityId].set(componentId);

    // std::cout << "Component id = " + std::to_string(componentId) + " was added to entity id = " + std::to_string(entityId) << std::endl;
}

template <typename T, typename... TArgs>
void ECSManager::AddComponent(std::shared_ptr<Entity> entity, TArgs &&... args)
{
    const auto entityId = entity->GetId();
    AddComponentById<T>(entityId, std::forward<TArgs>(args)...);
}

template <typename T>
void ECSManager::RemoveComponentById(int entityId)
{
    const auto componentId = Component<T>::GetId();
    entityComponentSignatures[entityId].set(componentId, false);
    // std::cout << "Component id = " + std::to_string(componentId) + " was removed from entity id = " + std::to_string(entityId) << std::endl;
}

template <typename T>
void ECSManager::RemoveComponent(std::shared_ptr<Entity> entity)
{
    const auto entityId = entity->GetId();
    RemoveComponentById<T>(entityId);
}

template <typename T>
bool ECSManager::HasComponentById(int entityId)
{
    const auto componentId = Component<T>::GetId();

    return entityComponentSignatures[entityId].test(componentId);
}

template <typename T>
bool ECSManager::HasComponent(std::shared_ptr<Entity> entity)
{
    const auto entityId = entity->GetId();

    return HasComponentById<T>(entityId);
}

template <typename T>
T &ECSManager::GetComponent(std::shared_ptr<Entity> entity)
{
    const auto entityId = entity->GetId();

    return GetComponentById<T>(entityId);
}

template <typename T>
T &ECSManager::GetComponentById(int entityId)
{
    const auto componentId = Component<T>::GetId();
    auto componentVector = std::static_pointer_cast<ComponentVector<T>>(componentVectors[componentId]);

    return componentVector->Get(entityId);
}

#endif