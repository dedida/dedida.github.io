/*
 *  @file   System.h
 *  @brief  System class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef SYSTEM_H
#define SYSTEM_H

#include <memory>
#include <vector>

#include "Constants.h"
#include "Component.h"
#include "Entity.h"
#include "ECSManager.h"

/**
 * The system is responsible for handling and managing entities and thier components
 */
class System
{
private:
    Signature componentSignature;
    std::vector<std::shared_ptr<Entity>> entities;

public:
    /**
      * Constructor of class System 
      */
    System() = default;
    ~System() = default;
    /**
    * Method used to add an entity to a system 
    * @param entity shared pointer 
    */
    void AddEntityToSystem(std::shared_ptr<Entity> entity);
    /**
    * Method used to remove an entity from a system
    * @param entity shared pointer 
    */
    void RemoveEntityFromSystem(std::shared_ptr<Entity> entity);
    /**
    * Method used to get systems entities 
    * @return shared pointer to vector of entities
    */
    std::vector<std::shared_ptr<Entity>> GetSystemEntities();
    /**
    * Method used to get a component's signature 
    * @return Signature reference
    */
    const Signature &GetComponentSignature();

    template <typename T>
    /**
    * Method used to make sure a game entity has a specific component 
    */
    void RequireComponent();
};

//////////////////////////////////////////////////////////////////////////////////////////
// Template function definitions below
//////////////////////////////////////////////////////////////////////////////////////////

template <typename T>
void System::RequireComponent()
{
    const auto componentId = Component<T>::GetId();
    componentSignature.set(componentId);
}

#endif