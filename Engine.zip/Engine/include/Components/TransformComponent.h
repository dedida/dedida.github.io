/*
 *  @file   TransformComponent.h
 *  @brief  TransformComponent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef TRANSFORMCOMPONENT_H
#define TRANSFORMCOMPONENT_H

#include "TinyMath.hpp"

/**
      * TransformComponent used to manage position changes for an entity 
      */
struct TransformComponent
{
    /**
     * Vector2D used to store position
     */
    Vector2D position;
    /**
     * Vector2D used to store scale
     */
    Vector2D scale;
    /**
     * float for orientation of object
     */
    float rotation;

    /**
      * Constructor of TransformComponent
      */
    TransformComponent(Vector2D position = Vector2D(0, 0), Vector2D scale = Vector2D(1, 1), float rotation = 0)
    {
        this->position = position;
        this->scale = scale;
        this->rotation = rotation;
    }
};
#endif