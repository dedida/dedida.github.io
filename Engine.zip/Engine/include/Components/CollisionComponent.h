/*
 *  @file   CollisionComponent.h
 *  @brief  CollisionComponent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef COLLISIONCOMPONENT_H
#define COLLISIONCOMPONENT_H

#include "TinyMath.hpp"

/**
     * Collision Component for moving objects
     */
struct CollisionComponent
{
    /**
     * int width of object 
     */
    int width;
    /**
     * int height of object
     */
    int height;
    /**
     * Vector2D to change movement after collision
     */
    Vector2D offset;

    /**
      * Constructor of CollisionComponent
      */
    CollisionComponent(int width = 0, int height = 0, Vector2D offset = Vector2D(0.0, 0.0))
    {
        this->width = width;
        this->height = height;
        this->offset = offset;
    }
};
#endif