/*
 *  @file   StaticCollision.h
 *  @brief  StaticCollision class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef STATICCOLLISIONCOMPONENT_H
#define STATICCOLLISIONCOMPONENT_H

#include "TinyMath.hpp"

/**
 * Similar to a collision component, but signifies that the object is not moving
 */
struct StaticCollisionComponent
{
    /**
     * int width size of object
     */
    int width;
    /**
     * int height size of object
     */
    int height;
    /**
     * Vector2D used to store offset
     */
    Vector2D offset;

    /**
      * Constructor of StaticCollisionComponent
      */
    StaticCollisionComponent(int width = 0, int height = 0, Vector2D offset = Vector2D(0.0, 0.0))
    {
        this->width = width;
        this->height = height;
        this->offset = offset;
    }
};
#endif