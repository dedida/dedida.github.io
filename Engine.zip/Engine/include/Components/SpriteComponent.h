/*
 *  @file   SpriteComponent.h
 *  @brief  SpriteComponent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef SPRITECOMPONENT_H
#define SPRITECOMPONENT_H

#include <string>

#include <SDL2/SDL.h>

/**
     * SpriteComponent used to manage image for game entities 
     */
struct SpriteComponent
{
    /**
     * int for width 
     */
    int width;
    /**
     * int for height
     */
    int height;
    /**
     * int to represent zIndex
     */
    int zIndex;
    /**
     * string to get asset from resourceManager
     */
    std::string assetId;
    /**
     * SDL_Rect where sprite comes from
     */
    SDL_Rect src;

    /**
      * Constructor of SpriteComponent
      */
    SpriteComponent(std::string assetId = "", int w = 0, int h = 0, int zIndex = 0, int srcX = 0, int srcY = 0)
    {
        this->assetId = assetId;
        this->width = w;
        this->height = h;
        this->zIndex = zIndex;
        this->src = {srcX, srcY, width, height};
    }
};
#endif