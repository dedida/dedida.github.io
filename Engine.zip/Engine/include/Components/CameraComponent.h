/*
 *  @file   CameraComponent.h
 *  @brief  CameraComponent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef CAMERACOMPONENT_H
#define CAMERACOMPONENT_H

/**
     * CameraComponent contains information about the game camera and signifies the entity the camera should follow.
     */
struct CameraComponent {
    int cameraWidth;
    int cameraHeight;
    int mapWidth;
    int mapHeight;
    CameraComponent(int cameraWidth=0, int cameraHeight=0, int mapWidth=0, int mapHeight=0) {
        this->cameraWidth = cameraWidth;
        this->cameraHeight = cameraHeight;
        this->mapWidth = mapWidth;
        this->mapHeight = mapHeight;
        if (mapWidth < cameraWidth) {
            this->mapWidth = cameraWidth;
        }
        if (mapHeight < cameraHeight) {
            this->mapHeight = cameraHeight;
        }
    }
};


#endif