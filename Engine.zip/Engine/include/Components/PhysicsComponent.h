/*
 *  @file   PhysicsComponent.h
 *  @brief  PhysicsComponent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef PHYSICSCOMPONENT_H
#define PHYSICSCOMPONENT_H

#include "TinyMath.hpp"

/**
 * PhysicsComponent used to manage velocity 
 */
struct PhysicsComponent
{
    /**
     * Vector2D used to store velocity 
     */
    Vector2D velocity;

    /**
      * Constructor of PhysicsComponent
      */
    PhysicsComponent(Vector2D velocity = Vector2D(0.0, 0.0))
    {
        this->velocity = velocity;
    }
};
#endif
