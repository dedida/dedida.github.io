/*
 *  @file   AnimationComponent.h
 *  @brief  AnimationComponent class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef ANIMATIONCOMPONENT_H
#define ANIMATIONCOMPONENT_H

#include <SDL2/SDL.h>

/**
     * AnimationComponent handles the frames that cycle through for a graphic
     */
struct AnimationComponent
{
    /**
     * int to show total number of frames 
     */
    int numFrames;
    /**
     * int frame component is on
     */
    int currentFrame;
    /**
     * int for how fast the frames should cycle through
     */
    int frameSpeedRate;
    /**
     * bool to tell if frame needs to be cycled through
     */
    bool isLoop;
    /**
     * int for start time
     */
    int startTime;

    /**
      * Constructor of AnimationComponent 
      */
    AnimationComponent(int numFrames = 1, int frameSpeedRate = 1, bool isLoop = true)
    {
        this->numFrames = numFrames;
        this->currentFrame = 1;
        this->frameSpeedRate = frameSpeedRate;
        this->isLoop = isLoop;
        this->startTime = SDL_GetTicks();
    }
};
#endif