/*
 *  @file   Entity.hpp
 *  @brief  Entity class interface 
 *  @date   2021-04-22
 ***********************************************/
#ifndef ENTITY_H
#define ENTITY_H

#include <string>

/**
 * The entity is responsible for handling and managing various components that house game data
 */
class Entity
{
private:
    /**
    * Int used as an ID for an entity 
    */
    int id;
    /**
    * String used to label the entity 
    */
    std::string name;

public:
    /**
      * Constructor of class Entity 
      */
    Entity(int id) : id(id){};
    Entity(std::string name, int id) : name(name), id(id){};
    Entity(const Entity &entity) = default;

    /**
    * Method used to get the entity id
    */
    int GetId() const;
    /**
    * Method used to get the entity name
    */
    std::string GetName() const;

    Entity &operator=(const Entity &other) = default;
    bool operator==(const Entity &other) const { return id == other.id; };
    bool operator!=(const Entity &other) const { return id != other.id; };
    bool operator<(const Entity &other) const { return id < other.id; };
    bool operator>(const Entity &other) const { return id > other.id; };

    template <typename T, typename... TArgs>
    /**
    * Method used to add a component 
    * @param component 
    */
    void AddComponent(TArgs &&... args);
    template <typename T>
    /**
    * Method used to remove a component 
    */
    void RemoveComponent();
    template <typename T>
    /**
    * Method used to check if an entity has a type of component 
    */
    bool HasComponent();
    template <typename T>
    /**
    * Method used to get a component from an entity
    * @return reference to a component 
    */
    T &GetComponent();
};

//////////////////////////////////////////////////////////////////////////////////////////
// Template function definitions below
////////////////////////////////////////////////////////////////////////////////////////////

// template <typename T, typename ...TArgs>
// void Entity::AddComponent(TArgs&& ...args) {
//     this->ecsManager->AddComponent<T>(*this, std::forward<TArgs>(args)...);
// }

// template <typename T>
// void Entity::RemoveComponent() {
//     this->ecsManager->RemoveComponent<T>(*this);
// }

// template <typename T>
// bool Entity::HasComponent() {
//     return this->ecsManager->HasComponent<T>(*this);
// }

// template <typename T>
// T& Entity::GetComponent() {
//     return this->ecsManager->GetComponent<T>(*this);
// }

#endif