#include "EventBus.h"

void EventBus::PublishKeyBoardEvent(KeyBoardEvent& event) {
    keyboardEvents.push_back(std::make_shared<KeyBoardEvent>(event));
}

void EventBus::PublishCollisionEvent(CollisionEvent& event) {
    collisionEvents.push_back(std::make_shared<CollisionEvent>(event));
}

void EventBus::ClearEvents() {
    keyboardEvents.clear();
    collisionEvents.clear();
}