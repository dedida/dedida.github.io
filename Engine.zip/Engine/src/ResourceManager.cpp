#include "ResourceManager.h"

ResourceManager::ResourceManager()
{
}

ResourceManager::~ResourceManager()
{
    ClearAssets();
}

void ResourceManager::ClearAssets()
{
    for (auto texture : textures)
    {
        SDL_DestroyTexture(texture.second);
    }
    textures.clear();
}

void ResourceManager::AddTexture(SDL_Renderer *renderer, const std::string &assetId, const std::string &filePath)
{
    SDL_Surface *surface = IMG_Load(filePath.c_str());
    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);

    textures.emplace(assetId, texture);

    std::cout << "New texture added to ResourceManager with id = " << assetId << std::endl;
}

SDL_Texture *ResourceManager::GetTexture(const std::string &assetId)
{
    return textures[assetId];
}

SDL_Texture *ResourceManager::loadTexture(std::string filePath, SDL_Renderer *renderer)
{
    if (textureMap.find(filePath) != textureMap.end())
    {
        return textureMap.at(filePath);
    }
    else
    {
        // create resource
        SDL_Texture *texture = IMG_LoadTexture(renderer, filePath.c_str());
        // store in dict
        textureMap[filePath] = texture;
        if (textureMap[filePath] == NULL)
        {
            SDL_Log("Failed to insert into Texture Map");
            std::cout << filePath << std::endl;
        }
        return texture;
    }
}
TTF_Font *ResourceManager::loadFont(std::string filePath, int fontSize)
{
    if (fontMap.find(filePath) != fontMap.end())
    {
        return fontMap.at(filePath);
    }
    else
    {
        //Initialize SDL_ttf
        if (TTF_Init() == -1)
        {
            SDL_Log("SDL_ttf could not initialize! SDL_ttf Error: %s\n", TTF_GetError());
        }
        // create resource
        TTF_Font *font = TTF_OpenFont(filePath.c_str(), fontSize);
        // store in dict
        fontMap.insert({filePath, font});
        if (fontMap.at(filePath) != font)
            SDL_Log("Failed to insert into map");
        return font;
    }
}

Mix_Music *ResourceManager::loadMusic(std::string filePath)
{
    if (soundMap.find(filePath) != soundMap.end())
    {
        return soundMap.at(filePath);
    }
    else
    {
        // create resource
        Mix_Music *sound = Mix_LoadMUS(filePath.c_str());
        // store in dict
        soundMap[filePath] = sound;
        return sound;
    }
}

Mix_Chunk *ResourceManager::loadWAV(std::string filePath)
{
    if (soundEffectMap.find(filePath) != soundEffectMap.end())
    {
        return soundEffectMap.at(filePath);
    }
    else
    {
        // create resource
        Mix_Chunk *sound = Mix_LoadWAV(filePath.c_str());
        // store in dict
        soundEffectMap[filePath] = sound;
        return sound;
    }
}