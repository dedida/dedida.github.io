#include "Engine.h"

Engine::Engine()
{
}

Engine::~Engine()
{
}

void Engine::Initialize(int windowWidth, int windowHeight)
{
    this->windowWidth = windowWidth;
    this->windowHeight = windowHeight;
    isRunning = false;
    resourceManager = std::make_unique<ResourceManager>();
    ecsManager = std::make_shared<ECSManager>();
    eventBus = std::make_unique<EventBus>();
    if (SDL_Init(SDL_INIT_EVERYTHING) != 0)
    {
        std::cout << "Error initializing SDL\n";
        return;
    }
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
    {
        std::cout << "Error" << Mix_GetError() << std::endl;
    }

    SDL_DisplayMode displayMode;
    SDL_GetCurrentDisplayMode(0, &displayMode);

    // Full screen size below
    // windowWidth = displayMode.w;
    // windowHeight = displayMode.h;

    window = SDL_CreateWindow(
        NULL,
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        windowWidth,
        windowHeight,
        SDL_WINDOW_BORDERLESS);
    if (!window)
    {
        std::cout << "Error creating SDL Window\n";
        return;
    }

    renderer = SDL_CreateRenderer(window, -1, 0);
    if (!renderer)
    {
        std::cout << "Error creating SDL Renderer\n";
        return;
    }

    // Add systems
    std::cout << "Adding systems\n";
    ecsManager->AddSystem<RenderSystem>();
    ecsManager->AddSystem<MovementSystem>();
    ecsManager->AddSystem<AnimationSystem>();
    ecsManager->AddSystem<StaticCollisionSystem>();
    ecsManager->AddSystem<CollisionSystem>();
    ecsManager->AddSystem<CameraFollowSystem>();
    std::cout << "Finished systems\n";

    camera.x = 0;
    camera.y = 0;
    camera.w = windowWidth;
    camera.h = windowHeight;
    isRunning = true;
}

void Engine::LoadTileMapImage(std::string filePath)
{
    resourceManager->AddTexture(renderer, "tilemap-image", filePath);
}

void Engine::Update()
{
    int timeToWait = MILLISECONDS_PER_FRAME - (SDL_GetTicks() - millisecondsLastFrame);
    if (timeToWait > 0 && timeToWait <= MILLISECONDS_PER_FRAME)
    {
        SDL_Delay(timeToWait);
    }

    float deltaTime = (SDL_GetTicks() - millisecondsLastFrame) / 1000.0f;

    millisecondsLastFrame = SDL_GetTicks();
    // Update Entity Manager
    ecsManager->Update();

    // Update all systems
    ecsManager->GetSystem<MovementSystem>().Update(deltaTime, ecsManager);
    StaticCollisionSystem staticCollision = ecsManager->GetSystem<StaticCollisionSystem>();
    ecsManager->GetSystem<CollisionSystem>().Update(eventBus, ecsManager, staticCollision);
    ecsManager->GetSystem<CameraFollowSystem>().Update(ecsManager, camera);
}

void Engine::Render()
{
    // std::cout << "starting rendering \n";
    SDL_SetRenderDrawColor(renderer, 66, 135, 245, 255);
    // std::cout << "finished setting draw color \n";
    SDL_RenderClear(renderer);

    if (bgImagePath.compare("none") != 0)
    {

        SDL_RenderCopy(renderer, resourceManager->loadTexture(bgImagePath, renderer), NULL, NULL);
    }

    // Render Entities
    // std::cout << "starting rendering systems \n";
    ecsManager->GetSystem<RenderSystem>().Update(renderer, ecsManager, resourceManager, camera);
    ecsManager->GetSystem<AnimationSystem>().Update(ecsManager);
    // std::cout << "finished rendering entities\n";
    for (GeneralDisplayPtr g : m_general_display)
    {
        g->Render();
    }

    SDL_RenderPresent(renderer);
}

void Engine::ProcessInput()
{
    SDL_Event event;
    KeyBoardEvent keyEvent;
    while (SDL_PollEvent(&event))
    {
        switch (event.type)
        {
        case SDL_QUIT:
            isRunning = false;
            break;
        case SDL_KEYDOWN:
            if (event.key.keysym.sym == SDLK_ESCAPE)
            {
                isRunning = false;
            }
            keyEvent = KeyBoardEvent(event);
            eventBus->PublishKeyBoardEvent(keyEvent);
            break;
        case SDL_KEYUP:
            keyEvent = KeyBoardEvent(event);
            eventBus->PublishKeyBoardEvent(keyEvent);
            break;
        }
    }
}

//// TO BE DELETED (probably) //////
void Engine::Run()
{
    while (isRunning)
    {
        ProcessInput();
        Update();
        Render();
    }
}

// mapFilePath - the string path to the .txt file
// mapWidth - the total width of the entire level
// mapHeight - the total height of the entire level
// tileMapWidth - the total width of the tile map sprite sheet
void Engine::LoadTileMap(std::string mapFilePath, int mapWidth, int mapHeight, int tileMapWidth)
{
    int tileSize = 16;
    int tileScale = 1.0;
    std::ifstream levelFile(mapFilePath);

    // Turn the dimensions in number of tiles
    mapHeight = floor(mapHeight / tileSize);
    mapWidth = floor(mapWidth / tileSize);
    tileMapWidth = floor(tileMapWidth / tileSize);

    if (levelFile)
    {
        std::cout << "File loaded\n";
    }

    int type;
    for (int y = 0; y < mapHeight; y++)
    {
        for (int x = 0; x < mapWidth; x++)
        {
            levelFile >> type;
            // std::cout << type << " ";

            if (type > 0)
            {
                int height = floor((type - 1) / tileMapWidth) * tileSize;
                int width = ((type - 1) % tileMapWidth) * tileSize;

                std::cout << type << ", " << width << " " << height << std::endl;

                std::shared_ptr<Entity> tile = ecsManager->CreateEntity("tile");
                ecsManager->AddComponent<TransformComponent>(tile, Vector2D(x * (tileScale * tileSize), y * (tileScale * tileSize)), Vector2D(tileScale, tileScale), 0.0);
                ecsManager->AddComponent<SpriteComponent>(tile, "tilemap-image", tileSize, tileSize, 0, width, height);
                ecsManager->AddComponent<StaticCollisionComponent>(tile, tileSize, tileSize);
            }
        }
        // std::cout << std::endl;
    }
}
void Engine::generateTileComponents(int mapWidth, int mapHeight, int tileMapWidth, int x, int y, bool Collision, int type)
{
    std::cout << "HI I am tile\n";
    int tileSize = 32;
    int tileScale = 1.0;
    mapHeight = floor(mapHeight / tileSize);
    mapWidth = floor(mapWidth / tileSize);
    tileMapWidth = floor(tileMapWidth / tileSize);

    int height = floor((type - 1) / tileMapWidth) * tileSize;
    int width = ((type - 1) % tileMapWidth) * tileSize;

    std::shared_ptr<Entity> tile = ecsManager->CreateEntity("tile");
    ecsManager->AddComponent<TransformComponent>(tile, Vector2D(x * (tileScale), y * (tileScale)), Vector2D(tileScale, tileScale), 0.0);
    ecsManager->AddComponent<SpriteComponent>(tile, "tilemap-image", tileSize, tileSize, 0, width, height);
    if (Collision)
    {
        ecsManager->AddComponent<StaticCollisionComponent>(tile, tileSize, tileSize);
    }
}

void Engine::Destroy()
{
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
//////////////////////////////////////////////////////////////////////////////////
///////////////////// PYTHON HELPER FUNCTIONS ////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////

void Engine::AddTexture(std::string assetId, std::string filePath)
{
    // resourceManager->AddTexture(renderer, "goomba-image", "./Assets/images/goomba.png");
    resourceManager->AddTexture(renderer, assetId, filePath);
}

int Engine::CreateEntity(std::string name = "")
{
    std::shared_ptr<Entity> entity = ecsManager->CreateEntity(name);
    return entity->GetId();
}

void Engine::RemoveEntity(int entityId)
{
    ecsManager->RemoveEntityById(entityId);
}

void Engine::AddTransformComponent(int entityId, Vector2D position, Vector2D scale, float rotation = 0.0)
{
    ecsManager->AddComponentById<TransformComponent>(entityId, position, scale, rotation);
}

void Engine::UpdateTransformComponent(int entityId, Vector2D newPosition = Vector2D(0.0, 0.0))
{
    TransformComponent &transformComponent = ecsManager->GetComponentById<TransformComponent>(entityId);
    transformComponent.position = newPosition;
}

void Engine::AddSpriteComponent(int entityId, std::string assetId, int w, int h, int zIndex = 0, int srcX = 0, int srcY = 0)
{
    ecsManager->AddComponentById<SpriteComponent>(entityId, assetId, w, h, zIndex, srcX, srcY);
}

void Engine::RemoveSpriteComponent(int entityId)
{
    ecsManager->RemoveComponentById<SpriteComponent>(entityId);
}

void Engine::AddPhysicsComponent(int entityId, Vector2D velocity = Vector2D(0.0, 0.0))
{
    ecsManager->AddComponentById<PhysicsComponent>(entityId, velocity);
}

void Engine::UpdatePhysicsComponent(int entityId, Vector2D newVelocity = Vector2D(0.0, 0.0))
{
    PhysicsComponent &physicsComponent = ecsManager->GetComponentById<PhysicsComponent>(entityId);
    physicsComponent.velocity = newVelocity;
}

void Engine::RemovePhysicsComponent(int entityId)
{
    ecsManager->RemoveComponentById<PhysicsComponent>(entityId);
}

TransformComponent &Engine::GetTransformComponent(int entityId)
{
    TransformComponent &transform = ecsManager->GetComponentById<TransformComponent>(entityId);
    return transform;
}

PhysicsComponent &Engine::GetPhysicsComponent(int entityId)
{
    PhysicsComponent &physics = ecsManager->GetComponentById<PhysicsComponent>(entityId);
    return physics;
}

void Engine::AddAnimationComponent(int entityId, int numFrames = 1, int frameSpeedRate = 1, bool isLoop = true)
{
    ecsManager->AddComponentById<AnimationComponent>(entityId, numFrames, frameSpeedRate, isLoop);
}

void Engine::AddCollisionComponent(int entityId, int width = 0, int height = 0, Vector2D offset = Vector2D(0.0, 0.0), bool moving = true)
{
    if (moving)
    {
        ecsManager->AddComponentById<CollisionComponent>(entityId, width, height, offset);
    }
    else
    {
        ecsManager->AddComponentById<StaticCollisionComponent>(entityId, width, height, offset);
    }
}

CollisionComponent &Engine::GetCollisionComponent(int entityId)
{
    CollisionComponent &collision = ecsManager->GetComponentById<CollisionComponent>(entityId);
    return collision;
}

void Engine::RemoveCollisionComponent(int entityId)
{
    ecsManager->RemoveComponentById<CollisionComponent>(entityId);
}

StaticCollisionComponent &Engine::GetStaticCollisionComponent(int entityId)
{
    StaticCollisionComponent &collision = ecsManager->GetComponentById<StaticCollisionComponent>(entityId);
    return collision;
}

void Engine::AddCameraComponent(int entityId, int cameraWidth, int cameraHeight, int mapWidth, int mapHeight)
{
    ecsManager->AddComponentById<CameraComponent>(entityId, cameraWidth, cameraHeight, mapWidth, mapHeight);
}

std::vector<std::shared_ptr<KeyBoardEvent>> Engine::GetKeyBoardInputs()
{
    return eventBus->keyboardEvents;
}

std::vector<std::shared_ptr<CollisionEvent>> Engine::GetCollisions()
{
    return eventBus->collisionEvents;
}

void Engine::ClearEvents()
{
    eventBus->ClearEvents();
}

void Engine::AddGeneralDisplay(std::string ID, std::string fontFilePath, int xPos, int yPos, int height, int width, int r, int g, int b, std::string text, int numeric)
{
    TTF_Font *font = resourceManager->loadFont(fontFilePath, 30);
    std::shared_ptr<GeneralDisplay> gd_ptr(new GeneralDisplay(ID, renderer, font, xPos, yPos, height, width, r, g, b, text, numeric));
    m_general_display.push_back(gd_ptr);
}

void Engine::UpdateGeneralDisplayNumeric(std::string ID, int newVal)
{
    for (GeneralDisplayPtr g : m_general_display)
    {
        if (g->ID.compare(ID) == 0)
        {
            g->UpdateNumericValue(newVal);
        }
    }
}

void Engine::PlayMusic(std::string filePath)
{
    if (!Mix_PlayingMusic())
    {
        Mix_PlayMusic(resourceManager->loadMusic(filePath), -1);
    }
}

void Engine::PlaySound(std::string filePath)
{
    Mix_PlayChannel(-1, resourceManager->loadWAV(filePath), 0);
}

//////////////////////////////////////////////////////////////////////////////////
///////////////////// PYTHON BINDINGS ////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Creates a macro function that will be called
// whenever the module is imported into python
// 'mygameengine' is what we 'import' into python.
// 'm' is the interface (creates a py::module object)
//      for which the bindings are created.
//  The magic here is in 'template metaprogramming'
PYBIND11_MODULE(engine, m)
{
    m.doc() = "Engine class";

    py::class_<Engine>(m, "Engine")
        .def(py::init()) // constructor
        .def("Initialize", &Engine::Initialize)
        .def("LoadTileMapImage", &Engine::LoadTileMapImage)
        .def("LoadTileMap", &Engine::LoadTileMap)
        .def("generateTileComponents", &Engine::generateTileComponents)

        .def("Update", &Engine::Update)
        .def("Render", &Engine::Render)
        .def("ProcessInput", &Engine::ProcessInput)
        .def("CreateEntity", &Engine::CreateEntity)
        .def("RemoveEntity", &Engine::RemoveEntity)
        .def("AddTexture", &Engine::AddTexture)

        .def("AddTransformComponent", &Engine::AddTransformComponent)
        .def("AddSpriteComponent", &Engine::AddSpriteComponent)
        .def("AddPhysicsComponent", &Engine::AddPhysicsComponent)
        .def("AddAnimationComponent", &Engine::AddAnimationComponent)
        .def("AddCollisionComponent", &Engine::AddCollisionComponent)
        .def("AddCameraComponent", &Engine::AddCameraComponent)

        .def("UpdatePhysicsComponent", &Engine::UpdatePhysicsComponent)
        .def("UpdateTransformComponent", &Engine::UpdateTransformComponent)

        .def("GetPhysicsComponent", &Engine::GetPhysicsComponent, pybind11::return_value_policy::reference)
        .def("GetTransformComponent", &Engine::GetTransformComponent, pybind11::return_value_policy::reference)
        .def("GetCollisionComponent", &Engine::GetCollisionComponent, pybind11::return_value_policy::reference)
        .def("GetStaticCollisionComponent", &Engine::GetStaticCollisionComponent, pybind11::return_value_policy::reference)

        .def("RemoveSpriteComponent", &Engine::RemoveSpriteComponent)
        .def("RemovePhysicsComponent", &Engine::RemovePhysicsComponent)
        .def("RemoveCollisionComponent", &Engine::RemoveCollisionComponent)

        .def("GetKeyBoardInputs", &Engine::GetKeyBoardInputs)
        .def("GetCollisions", &Engine::GetCollisions)
        .def("ClearEvents", &Engine::ClearEvents)

        .def("AddGeneralDisplay", &Engine::AddGeneralDisplay)
        .def("UpdateGeneralDisplayNumeric", &Engine::UpdateGeneralDisplayNumeric)

        .def("PlayMusic", &Engine::PlayMusic)
        .def("PlaySound", &Engine::PlaySound)

        .def_readwrite("isRunning", &Engine::isRunning)
        .def_readwrite("bgImagePath", &Engine::bgImagePath);

    m.doc() = "Vector 2D";
    py::class_<Vector2D>(m, "Vector2D")
        .def(py::init<float, float>(), py::arg("x"), py::arg("y"))
        .def_readwrite("x", &Vector2D::x)
        .def_readwrite("y", &Vector2D::y);

    /////////////////////// COMPONENTS //////////////////////////////
    m.doc() = "TransformComponent struct";
    py::class_<TransformComponent>(m, "TransformComponent")
        .def(py::init<Vector2D, Vector2D, float>(), py::arg("position"), py::arg("scale"), py::arg("rotation")) // constructor
        .def_readwrite("position", &TransformComponent::position)
        .def_readwrite("scale", &TransformComponent::scale)
        .def_readwrite("rotation", &TransformComponent::rotation);

    m.doc() = "SpriteComponent struct";
    py::class_<SpriteComponent>(m, "SpriteComponent")
        .def(py::init<std::string, int, int, int, int, int>(), py::arg("assetId"), py::arg("w"), py::arg("h"), py::arg("zIndex"), py::arg("srcX"), py::arg("srcY")); // constructor

    m.doc() = "AnimationComponent struct";
    py::class_<AnimationComponent>(m, "AnimationComponent")
        .def(py::init<int, int, bool>(), py::arg("numFrames"), py::arg("frameSpeedRate"), py::arg("isLoop")); // constructor

    m.doc() = "PhysicsComponent struct";
    py::class_<PhysicsComponent>(m, "PhysicsComponent")
        .def(py::init<Vector2D>(), py::arg("velocity"))
        .def_readwrite("velocity", &PhysicsComponent::velocity);

    m.doc() = "CollisionComponent struct";
    py::class_<CollisionComponent>(m, "CollisionComponent")
        .def(py::init<int, int, Vector2D>(), py::arg("width"), py::arg("height"), py::arg("offset"))
        .def_readwrite("width", &CollisionComponent::width)
        .def_readwrite("height", &CollisionComponent::height)
        .def_readwrite("offset", &CollisionComponent::offset);

    m.doc() = "StaticCollisionComponent struct";
    py::class_<StaticCollisionComponent>(m, "StaticCollisionComponent")
        .def(py::init<int, int, Vector2D>(), py::arg("width"), py::arg("height"), py::arg("offset"))
        .def_readwrite("width", &StaticCollisionComponent::width)
        .def_readwrite("height", &StaticCollisionComponent::height)
        .def_readwrite("offset", &StaticCollisionComponent::offset);

    /////////////////////// EVENTS //////////////////////////////

    m.doc() = "KeyBoardEvent class";
    py::class_<KeyBoardEvent, std::shared_ptr<KeyBoardEvent>>(m, "KeyBoardEvent")
        .def(py::init()) // constructor
        .def_readwrite("symbol", &KeyBoardEvent::symbol)
        .def_readwrite("eventType", &KeyBoardEvent::eventType);

    m.doc() = "CollisionEvent class";
    py::class_<CollisionEvent, std::shared_ptr<CollisionEvent>> collisionEvent(m, "CollisionEvent");
    collisionEvent.def(py::init()) // constructor
        .def_readwrite("entityId1", &CollisionEvent::entityId1)
        .def_readwrite("entityName1", &CollisionEvent::entityName1)
        .def_readwrite("entityId2", &CollisionEvent::entityId2)
        .def_readwrite("entityName2", &CollisionEvent::entityName2)
        .def_readwrite("type", &CollisionEvent::type);

    py::enum_<CollisionEvent::collisionType>(collisionEvent, "collisionType")
        .value("top", CollisionEvent::collisionType::top)
        .value("right", CollisionEvent::collisionType::right)
        .value("bottom", CollisionEvent::collisionType::bottom)
        .value("left", CollisionEvent::collisionType::left)
        .export_values();
}
