#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <chrono>
#include <SDL2/SDL.h>
#include <SDL2_ttf/SDL_ttf.h>
#include <SDL2_mixer/SDL_mixer.h>
#include <SDL2_image/SDL_image.h>

#include "Constants.h"
#include "ResourceManager.h"

#include "Python.h"

int main()
{
    TTF_Init();

    SDL_Window *window = SDL_CreateWindow(
        NULL,
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        SDL_WINDOW_BORDERLESS);
    SDL_Renderer *m_renderer = SDL_CreateRenderer(window, -1, 0);
    //GraphicsEngineRenderer *m_renderer = new GraphicsEngineRenderer(WINDOW_WIDTH, WINDOW_HEIGHT, MENU_IMAGE);
    ResourceManager resourceManager = ResourceManager();
    bool levelMade = false;
    bool startGame = false;
    bool quit = false;

    TTF_Font *buttonFont = TTF_OpenFont("Assets/fonts/ka1.ttf", 30);

    //TTF_Font *buttonFont = TTF_OpenFont("Assets/fonts/emulogic.ttf", 30);

    SDL_Surface *play = TTF_RenderText_Solid(buttonFont, "PLAY GALAGA", {57, 62, 70, 0xFF});
    SDL_Texture *playText = SDL_CreateTextureFromSurface(m_renderer, play);
    SDL_Surface *level = TTF_RenderText_Solid(buttonFont, "TILEMAP TOOL", {57, 62, 70, 0xFF});
    SDL_Texture *levelText = SDL_CreateTextureFromSurface(m_renderer, level);
    SDL_Surface *sprite = TTF_RenderText_Solid(buttonFont, "SPRITE TOOL", {57, 62, 70, 0xFF});
    SDL_Texture *spriteText = SDL_CreateTextureFromSurface(m_renderer, sprite);
    SDL_Surface *quit2 = TTF_RenderText_Solid(buttonFont, "QUIT ENGINE", {57, 62, 70, 0xFF});
    SDL_Texture *quitText = SDL_CreateTextureFromSurface(m_renderer, quit2);

    SDL_Rect play_rect;
    play_rect.x = BUTTON_X_POS;
    play_rect.y = PLAY_BUTTON_Y_POS;
    play_rect.w = BUTTON_WIDTH;
    play_rect.h = BUTTON_HEIGHT;

    SDL_Rect level_rect;
    level_rect.x = BUTTON_X_POS;
    level_rect.y = LEVEL_BUTTON_Y_POS;
    level_rect.w = BUTTON_WIDTH;
    level_rect.h = BUTTON_HEIGHT;

    SDL_Rect sprite_rect;
    sprite_rect.x = BUTTON_X_POS;
    sprite_rect.y = SPRITE_BUTTON_Y_POS;
    sprite_rect.w = BUTTON_WIDTH;
    sprite_rect.h = BUTTON_HEIGHT;

    SDL_Rect quit_rect;
    quit_rect.x = BUTTON_X_POS;
    quit_rect.y = QUIT_BUTTON_Y_POS;
    quit_rect.w = BUTTON_WIDTH;
    quit_rect.h = BUTTON_HEIGHT;

    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

    // Event handler that handles various events in SDL
    // that are related to input and output
    SDL_Event e;
    // Enable text input
    SDL_StartTextInput();
    //Handle events on queue
    SDL_RenderClear(m_renderer);
    SDL_RenderCopy(m_renderer, resourceManager.loadTexture(MENU_IMAGE, m_renderer), NULL, NULL);
    SDL_SetRenderDrawColor(m_renderer,
                           240, 138, 93,
                           255);

    SDL_RenderFillRect(m_renderer,
                       &play_rect);
    SDL_RenderFillRect(m_renderer,
                       &level_rect);
    SDL_RenderFillRect(m_renderer,
                       &sprite_rect);
    SDL_RenderFillRect(m_renderer,
                       &quit_rect);

    SDL_RenderCopy(m_renderer, playText, NULL, &play_rect);
    SDL_RenderCopy(m_renderer, levelText, NULL, &level_rect);
    SDL_RenderCopy(m_renderer, spriteText, NULL, &sprite_rect);
    SDL_RenderCopy(m_renderer, quitText, NULL, &quit_rect);

    SDL_RenderPresent(m_renderer);
    while (SDL_PollEvent(&e) != 0 || !startGame)
    {
        if (e.type == SDL_QUIT)
        {
            quit = true;
        }
        else if (e.type == SDL_KEYDOWN)
        {
            if (e.key.keysym.sym == SDLK_ESCAPE)
            {
                quit = true;
            }
            else if (e.key.keysym.sym == SDLK_q)
            {
                quit = true;
            }
            else if (e.key.keysym.sym == SDLK_p)
            {
                startGame = true;
            }
        }
        else if (e.type == SDL_MOUSEMOTION)
        {
            int x, y;
            SDL_GetMouseState(&x, &y);

            if (x >= BUTTON_X_POS && x <= (BUTTON_X_POS + BUTTON_WIDTH))
            {
                // inside play button
                if (y >= PLAY_BUTTON_Y_POS && y <= PLAY_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    SDL_RenderClear(m_renderer);
                    SDL_RenderCopy(m_renderer, resourceManager.loadTexture(MENU_IMAGE, m_renderer), NULL, NULL);
                    SDL_SetRenderDrawColor(m_renderer,
                                           240, 138, 93,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &level_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &sprite_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &quit_rect);

                    SDL_RenderCopy(m_renderer, levelText, NULL, &level_rect);
                    SDL_RenderCopy(m_renderer, spriteText, NULL, &sprite_rect);
                    SDL_RenderCopy(m_renderer, quitText, NULL, &quit_rect);

                    SDL_SetRenderDrawColor(m_renderer,
                                           252, 227, 138,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &play_rect);
                    SDL_RenderCopy(m_renderer, playText, NULL, &play_rect);

                    SDL_RenderPresent(m_renderer);
                }
                // inside level button
                else if (y >= LEVEL_BUTTON_Y_POS && y <= LEVEL_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    SDL_RenderClear(m_renderer);
                    SDL_RenderCopy(m_renderer, resourceManager.loadTexture(MENU_IMAGE, m_renderer), NULL, NULL);
                    SDL_SetRenderDrawColor(m_renderer,
                                           240, 138, 93,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &play_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &sprite_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &quit_rect);
                    SDL_RenderCopy(m_renderer, playText, NULL, &play_rect);
                    SDL_RenderCopy(m_renderer, spriteText, NULL, &sprite_rect);
                    SDL_RenderCopy(m_renderer, quitText, NULL, &quit_rect);

                    SDL_SetRenderDrawColor(m_renderer,
                                           252, 227, 138,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &level_rect);
                    SDL_RenderCopy(m_renderer, levelText, NULL, &level_rect);

                    SDL_RenderPresent(m_renderer);
                }
                else if (y >= SPRITE_BUTTON_Y_POS && y <= SPRITE_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    SDL_RenderClear(m_renderer);
                    SDL_RenderCopy(m_renderer, resourceManager.loadTexture(MENU_IMAGE, m_renderer), NULL, NULL);
                    SDL_SetRenderDrawColor(m_renderer,
                                           240, 138, 93,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &play_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &level_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &quit_rect);

                    SDL_RenderCopy(m_renderer, playText, NULL, &play_rect);
                    SDL_RenderCopy(m_renderer, levelText, NULL, &level_rect);
                    SDL_RenderCopy(m_renderer, quitText, NULL, &quit_rect);

                    SDL_SetRenderDrawColor(m_renderer,
                                           252, 227, 138,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &sprite_rect);
                    SDL_RenderCopy(m_renderer, spriteText, NULL, &sprite_rect);
                    SDL_RenderPresent(m_renderer);
                }

                // inside quit button
                else if (y >= QUIT_BUTTON_Y_POS && y <= QUIT_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    SDL_RenderClear(m_renderer);
                    SDL_RenderCopy(m_renderer, resourceManager.loadTexture(MENU_IMAGE, m_renderer), NULL, NULL);
                    SDL_SetRenderDrawColor(m_renderer,
                                           240, 138, 93,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &play_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &level_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &sprite_rect);

                    SDL_RenderCopy(m_renderer, playText, NULL, &play_rect);
                    SDL_RenderCopy(m_renderer, levelText, NULL, &level_rect);
                    SDL_RenderCopy(m_renderer, spriteText, NULL, &sprite_rect);

                    SDL_SetRenderDrawColor(m_renderer,
                                           252, 227, 138,
                                           255);
                    SDL_RenderFillRect(m_renderer,
                                       &quit_rect);
                    SDL_RenderCopy(m_renderer, quitText, NULL, &quit_rect);
                    SDL_RenderPresent(m_renderer);
                }
                else
                {
                    SDL_RenderClear(m_renderer);
                    SDL_RenderCopy(m_renderer, resourceManager.loadTexture(MENU_IMAGE, m_renderer), NULL, NULL);
                    SDL_SetRenderDrawColor(m_renderer,
                                           240, 138, 93,
                                           255);

                    SDL_RenderFillRect(m_renderer,
                                       &play_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &level_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &sprite_rect);
                    SDL_RenderFillRect(m_renderer,
                                       &quit_rect);

                    SDL_RenderCopy(m_renderer, playText, NULL, &play_rect);
                    SDL_RenderCopy(m_renderer, levelText, NULL, &level_rect);
                    SDL_RenderCopy(m_renderer, spriteText, NULL, &sprite_rect);
                    SDL_RenderCopy(m_renderer, quitText, NULL, &quit_rect);
                    SDL_RenderPresent(m_renderer);
                }
            }
        }
        else if (e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP)
        {
            int x, y;
            SDL_GetMouseState(&x, &y);

            if (x >= BUTTON_X_POS && x <= (BUTTON_X_POS + BUTTON_WIDTH))
            {
                // inside play button
                if (y >= PLAY_BUTTON_Y_POS && y <= PLAY_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    startGame = true;
                    if (levelMade)
                    {
                        system("cd .. && cd Engine");
                    }

                    SDL_DestroyWindow(window);

                    system("python3 Galaga.py");
                    exit(0);
                }
                // inside level button
                if (y >= LEVEL_BUTTON_Y_POS && y <= LEVEL_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    SDL_DestroyWindow(window);

                    system("cd .. && cd TileMap; python3 engineGame.py");
                    exit(0);
                    levelMade = true;
                }
                // inside sprite button
                if (y >= SPRITE_BUTTON_Y_POS && y <= SPRITE_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                     SDL_DestroyWindow(window);

                    system("python3 ../SpriteAnimator_tool/SpriteTool_GUI.py");
                    exit(0);
                    // insert script for sprite tool here
                }

                // inside quit button
                if (y >= QUIT_BUTTON_Y_POS && y <= QUIT_BUTTON_Y_POS + BUTTON_HEIGHT)
                {
                    startGame = true;
                    quit = true;
                }
            }
        }
    }
    SDL_StopTextInput();
    TTF_Quit();
    return 0;
}