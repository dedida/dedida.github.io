#include "ECSManager.h"

std::shared_ptr<Entity> ECSManager::CreateEntity(std::string name="")
{
    int entityId;

    if (freeIds.empty())
    {
        // If no reusable ids, then expand the entity ids
        entityId = numEntities++;
        if (entityId >= entityComponentSignatures.size())
        {
            entityComponentSignatures.resize(entityId + 1);
        }
    }
    else
    {
        // Reuse an id that was removed previously
        entityId = freeIds.front();
        freeIds.pop_front();
    }

    std::shared_ptr<Entity> entity = std::make_shared<Entity>(name, entityId);
    // entity->ecsManager = this;
    entitiesToBeAdded.insert(entity);

    if (entityId >= entityComponentSignatures.size())
    {
        entityComponentSignatures.resize(entityId + 1);
    }

    // std::cout << "Entity create with id = " + std::to_string(entityId) << std::endl;
    return entity;
}

void ECSManager::RemoveEntity(std::shared_ptr<Entity> entity)
{
    entitiesToBeKilled.insert(entity);
}

void ECSManager::RemoveEntityById(int entityId) {
    entityIdsToBeKilled.insert(entityId);
}

void ECSManager::AddEntityToSystems(std::shared_ptr<Entity> entity)
{
    const auto entityId = entity->GetId();

    const auto &entityComponentSignature = entityComponentSignatures[entityId];

    // Loop through all systems and check if the entity signature matches the requirements of the system
    for (auto &system : systems)
    {
        const auto &systemComponentSignature = system.second->GetComponentSignature();

        bool isInterested = (entityComponentSignature & systemComponentSignature) == systemComponentSignature;
        if (isInterested)
        {
            system.second->AddEntityToSystem(entity);
        }
    }
}

void ECSManager::RemoveEntityFromSystems(std::shared_ptr<Entity> entity)
{
    for (auto system : systems)
    {
        system.second->RemoveEntityFromSystem(entity);
    }
}

void ECSManager::RemoveEntityIdFromSystems(int entityId) {
    for (auto system : systems) {
        for (auto& entity : system.second->GetSystemEntities()) {
            if (entityId == entity->GetId()) {
                system.second->RemoveEntityFromSystem(entity);
            }
        }
    }
}

void ECSManager::Update()
{
    for (auto &entity : entitiesToBeAdded)
    {
        AddEntityToSystems(entity);
    }
    entitiesToBeAdded.clear();

    for (int entityId : entityIdsToBeKilled) {
        RemoveEntityIdFromSystems(entityId);
        entityComponentSignatures[entityId].reset();
        freeIds.push_back(entityId);
    }
    entityIdsToBeKilled.clear();

    for (auto &entity : entitiesToBeKilled)
    {
        RemoveEntityFromSystems(entity);
        entityComponentSignatures[entity->GetId()].reset();
        freeIds.push_back(entity->GetId());
    }
    entitiesToBeKilled.clear();
}