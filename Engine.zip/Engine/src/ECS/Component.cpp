#include "Component.h"

int BaseComponent::nextId = 0;