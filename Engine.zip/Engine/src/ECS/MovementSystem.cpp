#include "Systems/MovementSystem.h"

void MovementSystem::Update(float deltaTime, std::shared_ptr<ECSManager> &ecsManager)
{
    for (auto &entity : GetSystemEntities())
    {
        auto &transform = ecsManager->GetComponent<TransformComponent>(entity);
        const auto physics = ecsManager->GetComponent<PhysicsComponent>(entity);

        transform.position.x += physics.velocity.x * deltaTime;
        transform.position.y += physics.velocity.y * deltaTime;

    }
}