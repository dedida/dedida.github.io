#include "Entity.h"

int Entity::GetId() const
{
    return id;
}

std::string Entity::GetName() const {
    return name;
}
