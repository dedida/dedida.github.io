#include "CameraFollowSystem.h"

void CameraFollowSystem::Update(std::shared_ptr<ECSManager> &ecsManager, SDL_Rect& camera) {
    for (auto entity : GetSystemEntities()) {
        auto transform = ecsManager->GetComponent<TransformComponent>(entity);
        auto cameraComp = ecsManager->GetComponent<CameraComponent>(entity);

        if (transform.position.x + (camera.w / 2) < cameraComp.mapWidth) {
            camera.x = transform.position.x - (camera.w / 2);
        }
        if (transform.position.y + (camera.h / 2) <  cameraComp.mapHeight) {
            camera.y = transform.position.y - (camera.h / 2);
        }

        camera.x = camera.x < 0 ? 0 : camera.x;
        camera.y = camera.y < 0 ? 0 : camera.y;
        camera.x = camera.x > camera.w ? camera.w : camera.x;
        camera.y = camera.y > camera.h ? camera.h : camera.y;
    }
}