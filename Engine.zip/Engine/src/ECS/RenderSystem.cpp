#include "Systems/RenderSystem.h"

void RenderSystem::Update(SDL_Renderer *renderer, std::shared_ptr<ECSManager> &ecsManager, std::unique_ptr<ResourceManager> &resourceManager, SDL_Rect& camera)
{
    // Sort entities with sprite components by zIndex
    struct RenderableEntity
    {
        TransformComponent transformComponent;
        SpriteComponent spriteComponent;
    };
    std::vector<RenderableEntity> renderableEntities;
    for (auto &entity : GetSystemEntities())
    {
        RenderableEntity renderableEntity;
        renderableEntity.transformComponent = ecsManager->GetComponent<TransformComponent>(entity);
        renderableEntity.spriteComponent = ecsManager->GetComponent<SpriteComponent>(entity);
        renderableEntities.emplace_back(renderableEntity);
    }

    std::sort(renderableEntities.begin(), renderableEntities.end(), [](const RenderableEntity &a, const RenderableEntity &b) {
        return a.spriteComponent.zIndex < b.spriteComponent.zIndex;
    });

    for (auto entity : renderableEntities)
    {
        const auto transform = entity.transformComponent;
        const auto sprite = entity.spriteComponent;

        SDL_Rect src = sprite.src;
        SDL_Rect dest = {
            static_cast<int>(transform.position.x) - camera.x,
            static_cast<int>(transform.position.y) - camera.y,
            static_cast<int>(sprite.width * transform.scale.x),
            static_cast<int>(sprite.height * transform.scale.y)};

        SDL_RenderCopyEx(
            renderer,
            resourceManager->GetTexture(sprite.assetId),
            &src,
            &dest,
            transform.rotation,
            NULL,         // center of image as rotation point
            SDL_FLIP_NONE // do not flip image
        );
    }
}