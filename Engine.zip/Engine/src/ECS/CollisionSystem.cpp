#include "CollisionSystem.h"

void CollisionSystem::Update(std::unique_ptr<EventBus> &eventBus, std::shared_ptr<ECSManager> &ecsManager, StaticCollisionSystem& staticCollisionSystem)
{
    auto movingEntities = GetSystemEntities();
    auto staticEntities = staticCollisionSystem.GetSystemEntities();
    // Check moving against other moving objects
    for (int i = 0; i < movingEntities.size(); i++)
    {
        auto entity = movingEntities[i];
        auto transform1 = ecsManager->GetComponent<TransformComponent>(entity);
        auto collider1 = ecsManager->GetComponent<CollisionComponent>(entity);

        for (int j = i; j < movingEntities.size(); j++)
        {
            auto otherEntity = movingEntities[j];

            if (*entity == *otherEntity)
            {
                continue;
            }
            auto transform2 = ecsManager->GetComponent<TransformComponent>(otherEntity);
            auto collider2 = ecsManager->GetComponent<CollisionComponent>(otherEntity);

            bool collisionDetected = CheckAABBCollision(
                transform1.position.x + collider1.offset.x,
                transform1.position.y + collider1.offset.y,
                collider1.width,
                collider1.height,
                transform2.position.x + collider2.offset.x,
                transform2.position.y + collider2.offset.y,
                collider2.width,
                collider2.height
                );

            if (collisionDetected)
            {
                CollisionEvent::collisionType type = CheckCollisionDirection(
                    transform1.position.x + collider1.offset.x,
                    transform1.position.y + collider1.offset.y,
                    collider1.width,
                    collider1.height,
                    transform2.position.x + collider2.offset.x,
                    transform2.position.y + collider2.offset.y,
                    collider2.width,
                    collider2.height
                );
                CollisionEvent event(entity->GetId(), entity->GetName(), otherEntity->GetId(), otherEntity->GetName(), type);
                eventBus->PublishCollisionEvent(event);
                // std::cout << "Entity " << std::to_string(entity->GetId()) << " is colliding with entity " << std::to_string(otherEntity->GetId()) << std::endl;
            }
        }
    }

    // Check moving entities against the static objects
    for (int i = 0; i < movingEntities.size(); i++)
    {
        auto entity = movingEntities[i];
        auto transform1 = ecsManager->GetComponent<TransformComponent>(entity);
        auto collider1 = ecsManager->GetComponent<CollisionComponent>(entity);

        for (int j = 0; j < staticEntities.size(); j++)
        {
            auto otherEntity = staticEntities[j];

            if (*entity == *otherEntity)
            {
                continue;
            }
            auto transform2 = ecsManager->GetComponent<TransformComponent>(otherEntity);
            auto collider2 = ecsManager->GetComponent<StaticCollisionComponent>(otherEntity);

            bool collisionDetected = CheckAABBCollision(
                transform1.position.x + collider1.offset.x,
                transform1.position.y + collider1.offset.y,
                collider1.width,
                collider1.height,
                transform2.position.x + collider2.offset.x,
                transform2.position.y + collider2.offset.y,
                collider2.width,
                collider2.height
            );

            if (collisionDetected)
            {
                CollisionEvent::collisionType type = CheckCollisionDirection(
                    transform1.position.x + collider1.offset.x,
                    transform1.position.y + collider1.offset.y,
                    collider1.width,
                    collider1.height,
                    transform2.position.x + collider2.offset.x,
                    transform2.position.y + collider2.offset.y,
                    collider2.width,
                    collider2.height
                );
                CollisionEvent event(entity->GetId(), entity->GetName(), otherEntity->GetId(), otherEntity->GetName(), type);
                eventBus->PublishCollisionEvent(event);
                // std::cout << "Entity " << std::to_string(entity->GetId()) << " is colliding with entity " << std::to_string(otherEntity->GetId()) << std::endl;
            }
        }
    }
}


bool CollisionSystem::CheckAABBCollision(float aX, float aY, float aW, float aH, float bX, float bY, float bW, float bH)
{
    return (
        aX < bX + bW &&
        aX + aW > bX &&
        aY < bY + bH &&
        aY + aH > bY);
}

CollisionEvent::collisionType CollisionSystem::CheckCollisionDirection(float aX, float aY, float aW, float aH, float bX, float bY, float bW, float bH) {
    // https://stackoverflow.com/questions/5062833/detecting-the-direction-of-a-collision

    float bCollision = (bY + bH )- aY;
    float tCollision = (aY + aH) - bY;
    float lCollision = (aX + aW) - bX;
    float rCollision = (bX + bW) - aX;

    if ((tCollision < bCollision) && (tCollision < lCollision) && (tCollision < rCollision)) {
        return CollisionEvent::collisionType::top;
    }
    else if ((bCollision < tCollision) && (bCollision < lCollision) && (bCollision < rCollision)) {
        return CollisionEvent::collisionType::bottom;
    }
    else if ((lCollision < rCollision) && (lCollision < tCollision) && (lCollision < bCollision)) {
        return CollisionEvent::collisionType::left;
    }
    else {
        return CollisionEvent::collisionType::right;
    }


}