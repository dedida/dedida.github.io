#include "Systems/AnimationSystem.h"

void AnimationSystem::Update(std::shared_ptr<ECSManager> &ecsManager)
{
    for (auto entity : GetSystemEntities())
    {
        auto &animation = ecsManager->GetComponent<AnimationComponent>(entity);
        auto &sprite = ecsManager->GetComponent<SpriteComponent>(entity);

        animation.currentFrame = ((SDL_GetTicks() - animation.startTime) * animation.frameSpeedRate / 1000) % animation.numFrames;
        sprite.src.x = animation.currentFrame * sprite.width;
    }
}