#include "System.h"

void System::AddEntityToSystem(std::shared_ptr<Entity> entity) {
    entities.push_back(entity);
}

void System::RemoveEntityFromSystem(std::shared_ptr<Entity> entity) {
    entities.erase(std::remove_if(entities.begin(), entities.end(), [&entity](auto const& other) {
        return *entity == *other;
    }), entities.end());
}

std::vector<std::shared_ptr<Entity>> System::GetSystemEntities() {
    return entities;
}

const Signature& System::GetComponentSignature() {
    return componentSignature;
}