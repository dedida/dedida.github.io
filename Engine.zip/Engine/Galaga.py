from pyEngine import *
import random

engine = Engine()
resource_manager = ResourceManager(engine)

MAX_MOVEMENT_SPEED = 750
UPDATE_SPEED = 500
MAX_ENEMY_SPEED = 500
PROJECTILE_SPEED = 700
WINDOW_WIDTH = 960
WINDOW_HEIGHT = 640
LIVES = 3
SCORE = 0
def setup():
    resource_manager.AddTexture("rocket-image", "./Assets/images/rocket.png")
    resource_manager.AddTexture("enemy-image", "./Assets/images/Galaga-Enemy.png")
    resource_manager.AddTexture("bullet-image", "./Assets/images/bullet.png")

    main = GameEntity(engine, "main")
    main.AddTransformComponent((960/2 - 24, 640 - 53 - 30), (0.1, 0.1), 0.0)
    main.AddSpriteComponent("rocket-image", 577, 529, 1, 0, 0)
    main.AddPhysicsComponent((0.0, 0.0))
    main.AddCollisionComponent(57, 52, (0.0, 0.0))


def HandleCollisions(collisions, engine):
    global LIVES
    global SCORE
    for collision in collisions:
        if collision.entityName1 == "main" and collision.entityName2 == "enemy":
            enemy = engine.entityMap[collision.entityId2]
            main = engine.entityPool["main"][0]
            LIVES -= 1
            engine.RemoveEntity(enemy)
            engine.PlaySound("Assets/sounds/death.wav")
            engine.UpdateGeneralDisplayNumeric("hpDisplay", LIVES)

         

        elif collision.entityName2 == "main" and collision.entityName1 == "enemy":
            enemy = engine.entityMap[collision.entityId1]
            #LIVES -= 1
            engine.RemoveEntity(enemy)
            #engine.PlaySound("Assets/sounds/death.wav")
            #engine.UpdateGeneralDisplayNumeric("hpDisplay", LIVES)
  
        elif collision.entityName1 == "projectile" and collision.entityName2 == "enemy":
            enemy = engine.entityMap[collision.entityId2]
            projectile = engine.entityMap[collision.entityId1]
            # enemy.RemovePhysicsComponent()
            # projectile.RemovePhysicsComponent()
            engine.RemoveEntity(enemy)
            engine.RemoveEntity(projectile)


        elif collision.entityName2 == "projectile" and collision.entityName1 == "enemy":
            enemy = engine.entityMap[collision.entityId1]
            projectile = engine.entityMap[collision.entityId2]
            # enemy.RemovePhysicsComponent()
            # projectile.RemovePhysicsComponent()
            engine.RemoveEntity(enemy)
            engine.RemoveEntity(projectile)

            SCORE = SCORE + 1
            engine.UpdateGeneralDisplayNumeric("scoreDisplay", SCORE)



def HandleKeyEvents(engine,keyEvents):
    main = engine.entityPool["main"][0] # only one main character

    for key in keyEvents:
        velX, velY = main.GetVelocity()
        if (int(key.symbol)) > 127:
            continue
        if key.eventType == "KEYDOWN":
            if chr(int(key.symbol)) == "a":
                # move main character left
                newVel = velX - UPDATE_SPEED
                main.UpdateVelocity(max(-MAX_MOVEMENT_SPEED, newVel), 0.0)
            elif chr(int(key.symbol)) == 'd':
                # move right
                newVel = velX + UPDATE_SPEED
                main.UpdateVelocity(min(MAX_MOVEMENT_SPEED, newVel), 0.0)
            elif chr(int(key.symbol)) == ' ':
                # fire
                engine.PlaySound("Assets/sounds/lazer.wav")
                spawnProjectile(main)
            elif chr(int(key.symbol)) == 'q':
                engine.engine.isRunning = False
        elif key.eventType == "KEYUP":
            if chr(int(key.symbol)) == 'a':
                # stop moving left
                main.UpdateVelocity(0.0, 0.0)
            elif chr(int(key.symbol)) == 'd':
                # stop moving right
                main.UpdateVelocity(0.0, 0.0)

def spawnProjectile(entityFiring, up=True):
    xPos, yPos = entityFiring.GetPosition()
    width, height = entityFiring.GetDimensions()
    xPos = xPos + int(width/2)

    xVel = 0
    yVel = PROJECTILE_SPEED
    if up:
        yVel *= -1

    projectile = GameEntity(engine, "projectile")
    projectile.AddTransformComponent((xPos, yPos), (1.0, 10.0), 0.0)
    projectile.AddSpriteComponent("bullet-image", 4, 4, 1, 0, 0)
    projectile.AddPhysicsComponent((xVel, yVel))
    # main.AddAnimationComponent(1, 10, True)
    projectile.AddCollisionComponent(4, 4, (0.0, 0.0))

def spawnEnemy():
    xPos = random.randint(int(960/5), int(4*960/5))
    yPos = -65

    xVel = random.randint(-500, 500)
    yVel = random.randint(300, 500)
    newEnemy = GameEntity(engine, "enemy")
    newEnemy.AddTransformComponent((xPos, yPos), (0.1, 0.1), 0.0)
    newEnemy.AddSpriteComponent("enemy-image", 601, 553, 1, 0, 0)
    newEnemy.AddPhysicsComponent((xVel, yVel))
    # main.AddAnimationComponent(1, 10, True)
    newEnemy.AddCollisionComponent(60, 55, (0.0, 0.0))

def clamp(entity):
    xPos, yPos = entity.GetPosition()
    width, height = entity.GetDimensions()
    if xPos <= 0:
        newXPos = 0
        xVel, yVel = entity.GetVelocity()
        newXVel = -xVel if (entity.name != "main") else 0
        entity.UpdateVelocity(newXVel, yVel)
        entity.UpdatePosition(newXPos, yPos)
    elif xPos + width >= WINDOW_WIDTH:
        newXPos = WINDOW_WIDTH - width
        xVel, yVel = entity.GetVelocity()
        newXVel = -xVel if (entity.name != "main") else 0
        entity.UpdateVelocity(newXVel, yVel)
        entity.UpdatePosition(newXPos, yPos)
    elif entity.name == "enemy" and yPos > WINDOW_HEIGHT:
        # entity.RemovePhysicsComponent()
        engine.RemoveEntity(entity)



def clampMoving():
    for enemy in engine.entityPool["enemy"]:
        clamp(enemy)
    main = engine.entityPool["main"][0]
    clamp(main)

def main():
    engine.engine.bgImagePath = "Assets/images/star_background.png"

    setup()

    enemyCounter = 0
    systemCounter = 0

  
    engine.AddGeneralDisplay("scoreDisplay", "./Assets/fonts/emulogic.ttf", 0, 0, 50, 200, 255, 255, 255, "Score: ", SCORE)
    engine.AddGeneralDisplay("hpDisplay" , "./Assets/fonts/emulogic.ttf", 700, 0, 50, 200, 255, 255, 255, "Lives: ", LIVES)

    while engine.engine.isRunning and LIVES > 0:
        engine.PlayMusic("Assets/sounds/space.wav")
        engine.ProcessInput()
        keyEvents = engine.GetKeyBoardInputs()
        collisions = engine.GetCollisions()
        HandleCollisions(collisions, engine)
        engine.ClearEvents()
        clampMoving()
        HandleKeyEvents(engine,keyEvents)

        if enemyCounter % 75 == 0:
            for i in range(0, (systemCounter // 500) + 1):
                spawnEnemy()
            enemyCounter = 0
        systemCounter += 1
        enemyCounter += 1

        engine.Update()
        engine.Render()
    
    while engine.engine.isRunning:
        engine.ProcessInput()
        keyEvents = engine.GetKeyBoardInputs()
        engine.engine.bgImagePath = "Assets/images/GameOver.png"
        HandleKeyEvents(engine,keyEvents)
        engine.Update()
        engine.Render()



main()