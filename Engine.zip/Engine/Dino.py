from pyEngine import *
from math import floor

GRAVITY = 25.0
MAX_GRAVITY = 500.0

engine = Engine()
resource_manager = ResourceManager(engine)


def LoadMap(mapFilePath, mapWidth, mapHeight, tileMapWidth):
    tileSize = 16
    tileScale = 1.0
    # Turn the dimensions in number of tiles
    mapHeight = floor(mapHeight / tileSize)
    mapWidth = floor(mapWidth / tileSize)
    tileMapWidth = floor(tileMapWidth / tileSize)

    with open(mapFilePath) as f:
        lines = f.read().splitlines()

    y = 0
    for line in lines:
        x = 0
        for typ in line.split(' '):
            if typ == '':
                continue
            if int(typ) > 0:
                height = floor((int(typ) - 1) / tileMapWidth) * tileSize
                width = ((int(typ) - 1) % tileMapWidth) * tileSize
                tile = GameEntity(engine, "tile")
                tile.AddTransformComponent((x * (tileScale * tileSize), y * (tileScale * tileSize)), (tileScale, tileScale), 0.0)
                tile.AddSpriteComponent("tilemap-image", tileSize, tileSize, 0, width, height)
                tile.AddCollisionComponent(tileSize, tileSize, (0, 0), moving=False)
            x += 1
        y += 1

def setup():
    resource_manager.AddTexture("dino-image", "./Assets/images/newSprite.png")
    resource_manager.AddTexture("goomba-image", "./Assets/images/goomba.png")
    resource_manager.AddTexture("tilemap-image", "./Assets/images/Terrain.png")

    main_character = GameEntity(engine, "main")
    main_character.AddTransformComponent((0.0, 0.0), (1.0, 1.0), 0.0)
    main_character.AddSpriteComponent("dino-image", 24, 24, 1, 0, 0)
    main_character.AddPhysicsComponent((0.0, 0.0))
    main_character.AddAnimationComponent(13, 10, True)
    main_character.AddCollisionComponent(24, 24, (0.0, 0.0))
    main_character.AddCameraComponent(960, 640, 1920, 640)

    goomba = GameEntity(engine, "goomba")
    goomba.AddTransformComponent((50.0, 50.0), (0.1, 0.1), 0.0)
    goomba.AddSpriteComponent("goomba-image", 300, 300, 1, 0, 0)
    goomba.AddCollisionComponent(30, 30, (0.0, 0.0))
    goomba.AddPhysicsComponent((0.0, 0.0))

    LoadMap("./config/TestMap.txt", 1920, 640, 352)

def HandleKeyEvents(keyEvents):
    # Need to fix this later
    main_character = engine.entityPool["main"][0]
    for key in keyEvents:
        velX, velY = main_character.GetVelocity()
        if (int(key.symbol)) > 127:
            continue
        if key.eventType == "KEYDOWN":
            if chr(int(key.symbol)) == "a":
                # move main character left
                main_character.UpdateVelocity(-100.0, velY)
            elif chr(int(key.symbol)) == 'w':
                # move up
                main_character.UpdateVelocity(velX, -300.0)
            elif chr(int(key.symbol)) == 'd':
                # move right
                main_character.UpdateVelocity(100.0, velY)
        elif key.eventType == "KEYUP":
            if chr(int(key.symbol)) == 'a':
                # stop moving left
                main_character.UpdateVelocity(0.0, velY)
            elif chr(int(key.symbol)) == 'w':
                # stop moving up
                main_character.UpdateVelocity(velX, 0.0)
            elif chr(int(key.symbol)) == 'd':
                # stop moving right
                main_character.UpdateVelocity(0.0, velY)

def HandleCollisions(engine, collisions):
    for collision in collisions:
        if collision.entityName2 == "tile":
            mainPosX, mainPosY = engine.entityMap[collision.entityId1].GetPosition()
            mainVelX, mainVelY = engine.entityMap[collision.entityId1].GetVelocity()
            mainWidth, mainHeight = engine.entityMap[collision.entityId1].GetDimensions()
            tilePosX, tilePosY = engine.entityMap[collision.entityId2].GetPosition()
            tileWidth, tileHeight = engine.entityMap[collision.entityId2].GetDimensions()
            # print(tileWidth)

            if collision.type == collision.collisionType.top:
                engine.entityMap[collision.entityId1].UpdatePosition(mainPosX, tilePosY - mainHeight)
                engine.entityMap[collision.entityId1].UpdateVelocity(mainVelX, min(0, mainVelY))
            if collision.type == collision.collisionType.bottom:
                engine.entityMap[collision.entityId1].UpdatePosition(mainPosX, tilePosY + tileHeight)
                engine.entityMap[collision.entityId1].UpdateVelocity(mainVelX, min(0, mainVelY))
            if collision.type == collision.collisionType.right:
                engine.entityMap[collision.entityId1].UpdatePosition(tilePosX + tileWidth, mainPosY)
                # engine.entityMap[collision.entityId1].UpdateVelocity(0, mainVelY)
            if collision.type == collision.collisionType.left:
                engine.entityMap[collision.entityId1].UpdatePosition(tilePosX - mainWidth, mainPosY)
                # engine.entityMap[collision.entityId1].UpdateVelocity(0, mainVelY)
            
            



def ApplyGravity(gravityEntities):
    for entity in gravityEntities:
        velX, velY = entity.GetVelocity()
        newVelY = min(velY + GRAVITY, MAX_GRAVITY)
        entity.UpdateVelocity(velX, newVelY)

def main():
    setup()
    main_character = engine.entityPool["main"][0]
    goomba = engine.entityPool["goomba"][0]
    gravityEntities = [main_character, goomba]

    while engine.engine.isRunning:
        engine.ProcessInput()

        keyEvents = engine.GetKeyBoardInputs()
        collisions = engine.GetCollisions()
        HandleKeyEvents(keyEvents)
        ApplyGravity(gravityEntities)
        HandleCollisions(engine, collisions)
        engine.ClearEvents()

        

        engine.Update()
        engine.Render()



main()