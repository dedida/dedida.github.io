import os
 
COMPILER="c++"
 
SOURCE="./src/*.cpp ./src/*/*.cpp"
 
# You can can add other arguments as you see fit.
# What does the "-D MAC" command do? 
ARGUMENTS="-D MAC -std=c++17 -shared -fPIC -undefined dynamic_lookup -rpath ./"
 
# Which directories do we want to include.
#INCLUDE_DIR="-I ./include/ -I ./include/Components/ -I ./include/Systems/ -I ./include/Events/ -I/Library/Frameworks/SDL2.framework/Headers  -I./../common/thirdparty/old/glm  `python3.9 -m pybind11 --includes` -I/usr/local/Cellar/python@3.9/3.9.4/Frameworks/Python.framework/Versions/3.9/include/python3.9"
# don't delete below @dedida uses to run
INCLUDE_DIR="-I ./include/ -I ./include/Components/ -I ./include/Systems/ -I ./include/Events/ -I/Library/Frameworks/SDL2.framework/Headers  -I./../common/thirdparty/old/glm  -I/usr/local/Cellar/python@3.9/3.9.4/Frameworks/Python.framework/Versions/3.9/include/python3.9"

#LIBRARIES="-F/Library/Frameworks -framework SDL2_ttf -framework SDL2_mixer -framework SDL2_image -framework SDL2  `python3.9-config --ldflags` -framework Python"
# don't delete below @dedida uses to run
LIBRARIES="-F/Library/Frameworks -framework SDL2_ttf -framework SDL2_mixer -framework SDL2_image -framework SDL2 -framework Python"
 
# The name of our executable
EXECUTABLE="engine.so"
 
# Build a string of our compile commands that we run in the terminal
compileString=COMPILER+" "+ARGUMENTS+" -o "+EXECUTABLE+" "+" "+INCLUDE_DIR+" "+SOURCE+" "+LIBRARIES
 
# Print out the compile string
print(compileString)
 
# Run our command
os.system(compileString)