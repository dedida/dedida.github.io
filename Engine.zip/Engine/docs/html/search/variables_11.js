var searchData=
[
  ['text_476',['text',['../class_general_display.html#a78045fc876b216817e06f942a61d7494',1,'GeneralDisplay']]],
  ['type_477',['type',['../class_collision_event.html#a0b63c8f1868ad8b546560f725106823b',1,'CollisionEvent']]]
];
