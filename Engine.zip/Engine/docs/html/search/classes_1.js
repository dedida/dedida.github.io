var searchData=
[
  ['basecomponent_238',['BaseComponent',['../struct_base_component.html',1,'']]]
];
