var searchData=
[
  ['offset_464',['offset',['../struct_collision_component.html#ac9a36033af1e5a9d98627a710733044a',1,'CollisionComponent::offset()'],['../struct_static_collision_component.html#aa427c49585642b33445b6ddadca0ee26',1,'StaticCollisionComponent::offset()']]]
];
