var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxyz~",
  1: "abcegikmprstv",
  2: "acegkmprst",
  3: "acdeghiklmnoprstuv~",
  4: "abcefghiklmnopqrstvwxyz",
  5: "gs",
  6: "c",
  7: "blrt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator"
};

