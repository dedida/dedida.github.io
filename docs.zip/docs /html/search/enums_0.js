var searchData=
[
  ['collisiontype_491',['collisionType',['../class_collision_event.html#aec0b8de62787b3ff379830fe162c6c79',1,'CollisionEvent']]]
];
