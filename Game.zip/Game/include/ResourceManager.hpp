#ifndef RESOURCE_MANAGER_HPP
#define RESOURCE_MANAGER_HPP

// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>


class ResourceManager{
public:

  	// 'equivalent' to constructor
	//static ResourceManager* getInstance();

	static ResourceManager * getInstance(){
	if (!instance){
	    instance = new ResourceManager;
	}
    return instance;
}
	// 'equivalent' to destructor
	void Destroy();
	// adds surface and texture to maps
  	void init(const char * character, SDL_Renderer* ren);
	// returns character texture
	SDL_Texture* getTexture(const char * character);

	std::map<const char *, SDL_Surface*> surfaceMap;
	std::map<const char *, SDL_Texture*> textureMap;


private:
	static ResourceManager* instance;
	ResourceManager(); // Default constructor which is hidden in the Singleton
    ResourceManager(ResourceManager const&); // Avoid copy constructor
    void operator=(ResourceManager const&); // Don't allow assignment.


	SDL_Surface *spriteSheet;
	SDL_Texture *texture;

};

#endif
