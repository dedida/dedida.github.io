/*
 *  @file   ResourceManager.hpp
 *  @brief  ResourceManager class interface used to create a ResourceManager that handles the image assets of the game.
 *  @date   2021-02-22
 ***********************************************/
#ifndef RESOURCE_MANAGER_HPP
#define RESOURCE_MANAGER_HPP

#include <map>
#include <string>
#include <memory>
#include <iterator>
#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

/*! \brief      ResourceManager class used to create a ResourceManager that handles the image assets of the game.
 */
class ResourceManager
{
public:
	static ResourceManager *getInstance()
	{
		if (!instance)
		{
			instance = new ResourceManager;
		}
		return instance;
	}
	// 'equivalent' to destructor
	void Destroy();
	// adds surface and texture to maps
	void init(const char *character, SDL_Renderer *ren);
	// returns character texture

	SDL_Texture *getTexture(const char *character);
	std::map<const char *, SDL_Surface *> surfaceMap;
	std::map<const char *, SDL_Texture *> textureMap;

private:
	/*! \brief Constuctor for ResourceManager. Takes in no parameters and is only instantiated once. 
    */
	ResourceManager();						  // Default constructor which is hidden in the Singleton
	ResourceManager(ResourceManager const &); // Avoid copy constructor
	void operator=(ResourceManager const &);  // Don't allow assignment.
	static ResourceManager *instance;
	SDL_Surface *spriteSheet;
	SDL_Texture *texture;
};

#endif
