#ifndef Brick_hpp
#define Brick_hpp
#include "Vec2.hpp"
#include "Constants.hpp"
#include <SDL2/SDL.h>

class Brick
{
public:
    Brick()
    {
    }

    Brick(int x, int y) : x(x), y(y)
    {
        alive = 1;
        w = BRICK_WIDTH;
        h = BRICK_HEIGHT;
        x2 = x + BRICK_WIDTH;
        y2 = y + BRICK_HEIGHT;
    }

    int alive;
    int x;
    int y;
    int w;
    int h;
    int x2;
    int y2;

    // draw brick
    void Draw(SDL_Renderer *renderer, SDL_Texture *tex);

    // function set brick dead
    void KillBrick();
};

#endif /* Brick_hpp */