/*
 *  @file   Brick.hpp
 *  @brief  Brick class interface for brick for both drawing it and killing it
 *  @date   2021-02-22
 ***********************************************/
#ifndef Brick_hpp
#define Brick_hpp
#include "Vec2.hpp"
#include "Constants.hpp"
#include <SDL2/SDL.h>

/*! \brief      Brick class used to create brick, draw it, and kill it
 */
class Brick
{
public:
    /*! \brief Constuctor for brick. Takes in no parameters, the field values are set later during brick creation.
    */
    Brick()
    {
    }

    // draw brick
    void Draw(SDL_Renderer *renderer, SDL_Texture *tex);
    // function set brick dead
    void KillBrick();

    int alive;
    int x;
    int y;
    int w;
    int h;
    int x2;
    int y2;
};

#endif /* Brick_hpp */