/*
 *  @file   Vec2.hpp
 *  @brief  Vec2 class interface used to create a vector that handles the image assets of the game.
 *  @date   2021-02-22
 ***********************************************/
#ifndef Vec2_hpp
#define Vec2_hpp

/*! \brief      Vec2 class
 *  Used to create a vector used for movement in the game objects.
 */
class Vec2
{

public:
    /*! \brief Default constuctor for Vec2. Takes in no parameters and sets the x and y values to 0.0f
    */
    Vec2()
        : x(0.0f), y(0.0f)
    {
    }
    /*! \brief Constuctor for Vec2. Takes in 2 floats x and y.
    * @param float x
    * @param float y
    */
    Vec2(float x, float y)
        : x(x), y(y)
    {
    }

    Vec2 operator+(Vec2 const &rhs);
    Vec2 &operator+=(Vec2 const &rhs);
    Vec2 operator*(float rhs);

    float x, y;
};
#endif /* Vec2_hpp */