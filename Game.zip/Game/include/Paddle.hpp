/*
 *  @file   Paddle.hpp
 *  @brief  Paddle class interface to create the paddle, draw it, and update it
 *  @date   2021-02-22
 ***********************************************/
#ifndef Paddle_hpp
#define Paddle_hpp
#include "Vec2.hpp"
#include "Constants.hpp"
#include <SDL2/SDL.h>

/*! \brief      Paddle class used to create paddle, draw it, and update it
 */
class Paddle
{
public:
    /*! \brief Constuctor for paddle. Takes in a Vec2 position and a Vec2 velocity.
    * @param Vec2 position
    * @param Vec2 velocity
    */
    Paddle(Vec2 position, Vec2 velocity)
        : position(position), velocity(velocity)
    {
        rect.x = static_cast<int>(position.x);
        rect.y = static_cast<int>(position.y);
        rect.w = PADDLE_WIDTH;
        rect.h = PADDLE_HEIGHT;
    }

    void Update(float dt);
    void Draw(SDL_Renderer *renderer);

    Vec2 position;
    Vec2 velocity;
    SDL_Rect rect{};
};

#endif /* Paddle_hpp */