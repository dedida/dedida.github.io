#ifndef Paddle_hpp
#define Paddle_hpp
#include "Vec2.hpp"
#include "Constants.hpp"
#include <SDL2/SDL.h>

class Paddle
{
public:
    Vec2 position;
    Vec2 velocity;
    SDL_Rect rect{};
    Paddle(Vec2 position, Vec2 velocity)
        : position(position), velocity(velocity)
    {
        rect.x = static_cast<int>(position.x);
        rect.y = static_cast<int>(position.y);
        rect.w = PADDLE_WIDTH;
        rect.h = PADDLE_HEIGHT;
    }
    void Update(float dt);

    void Draw(SDL_Renderer *renderer);
};

#endif /* Paddle_hpp */