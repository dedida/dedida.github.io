/*
 *  @file   Constants.hpp
 *  @brief Sets values for settings that should not change. 
 *  @date   2021-02-22
 ***********************************************/
#ifndef Constants_hpp
#define Constants_hpp

const int WINDOW_WIDTH = 1280;
const int WINDOW_HEIGHT = 720;

const float BALL_SPEED = .3f;
const int BALL_WIDTH = 15;
const int BALL_HEIGHT = 15;

const float PADDLE_SPEED = .4f;
const int PADDLE_WIDTH = 120;
const int PADDLE_HEIGHT = 15;

const int BRICK_WIDTH = 100;
const int BRICK_HEIGHT = 25;

const int COLLISION_CUSHION = 3;

enum Buttons
{
    PaddleLeft = 0,
    PaddleRight,
};

enum class CollisionType
{
    None,
    Top,
    Middle,
    Bottom,
    Left,
    Right
};

struct Contact
{
    CollisionType type;
    float penetration;
};

#endif /* Constants_hpp */
