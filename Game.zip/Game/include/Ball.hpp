/*
 *  @file   Ball.hpp
 *  @brief  Ball class interface for ball and its movement
 *  @date   2021-02-22
 ***********************************************/
#ifndef Ball_hpp
#define Ball_hpp
#include "Vec2.hpp"
#include "Constants.hpp"
#include <SDL2/SDL.h>

/*! \brief      Ball class used to create ball and control its movement and collisions 
 */
class Ball
{
public:
    /*! \brief Constuctor for Ball. Takes in a Vec2 position and a a Vec2 velocity
    * @param Vec2 position
    * @param Vec2 velocity
    */
    Ball(Vec2 position, Vec2 velocity)
        : position(position), velocity(velocity)
    {
        rect.x = static_cast<int>(position.x);
        rect.y = static_cast<int>(position.y);
        rect.w = BALL_WIDTH;
        rect.h = BALL_HEIGHT;
    }

    void Update(float dt);
    void Draw(SDL_Renderer *renderer);
    void CollideWithPaddle(Contact const &contact);
    void CollideWithWall(Contact const &contact);
    void CollideWithBrick(Contact const &contact);

    Vec2 position;
    Vec2 velocity;
    SDL_Rect rect{};
};
#endif /* Ball_hpp */