/*
 *  @file   PlayerScore.hpp
 *  @brief  PlayerScore class interface used to create PlayerScore, draw it, and set the score 
 *  @date   2021-02-22
 ***********************************************/
#ifndef PlayerScore_hpp
#define PlayerScore_hpp
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <string>
#include "Vec2.hpp"
#include "Constants.hpp"
#include "Paddle.hpp"
#include "Ball.hpp"

/*! \brief      PlayerScore class used to create PlayerScore, draw it, and set the score 
 */
class PlayerScore
{
public:
    /*! \brief Constuctor for PlayerScore. Takes in a Vec2 position, a SDL_Renderer renderer, and a TFF_Font font.
    * @param Vec2 position
    * @param SDL_Renderer renderer
    * @param TFF_Font font 
    */
    PlayerScore(Vec2 position, SDL_Renderer *renderer, TTF_Font *font)
        : renderer(renderer), font(font)
    {
        surface = TTF_RenderText_Solid(font, "0", {147, 0, 119, 0xFF});
        texture = SDL_CreateTextureFromSurface(renderer, surface);

        int width, height;
        SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);

        rect.x = static_cast<int>(position.x);
        rect.y = static_cast<int>(position.y);
        rect.w = width;
        rect.h = height;
    }

    ~PlayerScore()
    {
        SDL_FreeSurface(surface);
        SDL_DestroyTexture(texture);
    }

    void Draw();

    void SetScore(int score);
    SDL_Renderer *renderer;
    TTF_Font *font;
    SDL_Surface *surface{};
    SDL_Texture *texture{};
    SDL_Rect rect{};
};

#endif /* PlayerScore_hpp */