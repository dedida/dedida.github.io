var searchData=
[
  ['setscore_17',['SetScore',['../class_player_score.html#aa88b17d890af0f3f4642d6fa36ca5b9a',1,'PlayerScore']]]
];
