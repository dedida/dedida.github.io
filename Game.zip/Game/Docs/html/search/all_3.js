var searchData=
[
  ['gettexture_8',['getTexture',['../class_resource_manager.html#afe2ee8a6f798c034b7888f46b4e56e9b',1,'ResourceManager']]]
];
