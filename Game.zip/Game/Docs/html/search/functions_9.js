var searchData=
[
  ['update_43',['Update',['../class_ball.html#a791a8547e5a882d05c1acc4cbfcee86b',1,'Ball::Update()'],['../class_paddle.html#a2e0edce0c38b90a057c373cebaadf160',1,'Paddle::Update()']]]
];
