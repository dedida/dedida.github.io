/*
 *  @file   Vec2.cpp
 *  @brief  Vec2 class interface used to create a vector that handles the image assets of the game.
 *  @date   2021-02-22
 ***********************************************/
#include "Vec2.hpp"

/*! \brief      Addition assignment operator
* @param Vec2 const rhs
*/
Vec2 Vec2::operator+(Vec2 const &rhs)
{
    return Vec2(x + rhs.x, y + rhs.y);
}

/*! \brief      Compound Addition assignment operator
* @param Vec2 const rhs
*/
Vec2 &Vec2::operator+=(Vec2 const &rhs)
{
    x += rhs.x;
    y += rhs.y;

    return *this;
}

/*! \brief      Multiplies x and y by float value
* @param float rhs
*/
Vec2 Vec2::operator*(float rhs)
{
    return Vec2(x * rhs, y * rhs);
}