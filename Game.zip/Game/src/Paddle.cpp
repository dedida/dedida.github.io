/*
 *  @file   Paddle.cpp
 *  @brief  Paddle class interface to create the paddle, draw it, and update it
 *  @date   2021-02-22
 ***********************************************/
#include "Paddle.hpp"
#include <SDL2/SDL.h>

/*! \brief      Draws the paddle
* @param SDL_Renderer renderer
*/
void Paddle::Draw(SDL_Renderer *renderer)
{
    rect.x = static_cast<int>(position.x);

    SDL_RenderFillRect(renderer, &rect);
}

/*! \brief      Updates the position of the paddle
* @param float ft
*/
void Paddle::Update(float dt)
{
    position += velocity * dt;

    if (position.x < 0)
    {
        // Restrict to left end of the screen
        position.x = 0;
    }
    else if (position.x > (WINDOW_WIDTH - PADDLE_WIDTH))
    {
        // Restrict to right end of the screen
        position.x = WINDOW_WIDTH - PADDLE_WIDTH;
    }
}