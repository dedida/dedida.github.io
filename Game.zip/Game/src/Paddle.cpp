#include "Paddle.hpp"
#include <SDL2/SDL.h>

void Paddle::Draw(SDL_Renderer *renderer)
{
    rect.x = static_cast<int>(position.x);

    SDL_RenderFillRect(renderer, &rect);
}
void Paddle::Update(float dt)
{
    position += velocity * dt;

    if (position.x < 0)
    {
        // Restrict to left end of the screen
        position.x = 0;
    }
    else if (position.x > (WINDOW_WIDTH - PADDLE_WIDTH))
    {
        // Restrict to right end of the screen
        position.x = WINDOW_WIDTH - PADDLE_WIDTH;
    }
}