/*
 *  @file   Ball.cpp
 *  @brief  Ball class interface for ball and its movement
 *  @date   2021-02-22
 ***********************************************/
#include "Ball.hpp"
#include <SDL2/SDL.h>

/*! \brief      Changes the position of the ball so it can have movement
* @param float dt 
*/
void Ball::Update(float dt)
{
    position += velocity * dt;
}

/*! \brief      Draws the ball 
* @param SDL_Renderer renderer
*/
void Ball::Draw(SDL_Renderer *renderer)
{
    rect.x = static_cast<int>(position.x);
    rect.y = static_cast<int>(position.y);

    SDL_RenderFillRect(renderer, &rect);
}

/*! \brief      When the ball collides with a paddle, its movement direction will change
* @param Contact const contact
*/
void Ball::CollideWithPaddle(Contact const &contact)
{
    position.y += contact.penetration;
    velocity.y = -velocity.y;

    if (contact.type == CollisionType::Left)
    {
        velocity.x = -.75f * BALL_SPEED;
    }
    else if (contact.type == CollisionType::Right)
    {
        velocity.x = 0.75f * BALL_SPEED;
    }
}

/*! \brief      When the ball collides with a wall, its movement direction will change
* @param Contact const contact
*/
void Ball::CollideWithWall(Contact const &contact)
{
    if (contact.type == CollisionType::Top)
    {
        position.y += contact.penetration;
        velocity.y = -velocity.y;
    }
    else if (contact.type == CollisionType::Left)
    {
        velocity.x = BALL_SPEED;
    }

    else if (contact.type == CollisionType::Right)
    {
        velocity.x = -BALL_SPEED;
    }
    // if ball goes to bottom restart starting position of ball
    else if (contact.type == CollisionType::Bottom)
    {
        position.x = (WINDOW_WIDTH / 2.0f) - (BALL_WIDTH / 2.0f);
        position.y = (WINDOW_HEIGHT - (PADDLE_WIDTH / 2.0f) - BALL_HEIGHT);
        velocity.x = 0.0f;
        velocity.y = -BALL_SPEED;
    }
}

/*! \brief      When the ball collides with a brick, its movement direction will change
* @param Contact const contact
*/
void Ball::CollideWithBrick(Contact const &contact)
{
    if (contact.type == CollisionType::Top)
    {
        position.y += contact.penetration;
        velocity.y = -velocity.y;
    }
    else if (contact.type == CollisionType::Left)
    {
        velocity.x = BALL_SPEED;
    }

    else if (contact.type == CollisionType::Right)
    {
        velocity.x = -BALL_SPEED;
    }
    // if ball goes to bottom restart starting position of ball
    else if (contact.type == CollisionType::Bottom)
    {
        position.y += contact.penetration;
        velocity.y = -velocity.y;
    }
}