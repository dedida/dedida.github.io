#include <SDL2/SDL.h>
// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>

#include "ResourceManager.hpp"

ResourceManager::ResourceManager() {}

void ResourceManager::Destroy(){

	std::map<const char *, SDL_Surface*>::iterator it = ResourceManager::surfaceMap.begin();
	while(it != ResourceManager::surfaceMap.end())	{
		SDL_FreeSurface(it->second);
		surfaceMap.erase (it->first);           
		it++;
	}
		std::map<const char *, SDL_Texture*>::iterator it2 = ResourceManager::textureMap.begin();
	while(it2 != ResourceManager::textureMap.end())	{
		SDL_DestroyTexture(it2->second);
		textureMap.erase (it->first);           
		it2++;
	}
}

SDL_Texture* ResourceManager::getTexture(const char * character){
		return  ResourceManager::textureMap[character];
}

void ResourceManager::init(const char * character, SDL_Renderer* ren){
	// if not in maps add to maps
	if (ResourceManager::surfaceMap.find(character) == ResourceManager::surfaceMap.end()){
		SDL_Log("Allocated one piece of memory to load game surface.");
		ResourceManager::surfaceMap[character] = IMG_Load(character);
	}
	if (ResourceManager::textureMap.find(character) == ResourceManager::textureMap.end()){
		SDL_Log("Allocated one piece of memory for game texture.");
		ResourceManager::textureMap[character] = SDL_CreateTextureFromSurface(ren, ResourceManager::surfaceMap[character]);
	}

}
