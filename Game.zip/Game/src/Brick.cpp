/*
 *  @file   Brick.cpp
 *  @brief  brick class interface for brick for both drawing it and killing it
 *  @date   2021-02-22
 ***********************************************/
#include "Brick.hpp"
#include <SDL2/SDL.h>

/*! \brief      Draws the brcik
* @param SDL_Renderer renderer
* @param SDL_Texture tex
*/
void Brick::Draw(SDL_Renderer *renderer, SDL_Texture *tex)
{
    SDL_Rect rect;
    rect.x = static_cast<int>(x);
    rect.y = static_cast<int>(y);
    rect.w = static_cast<int>(w);
    rect.h = static_cast<int>(h);

    SDL_RenderCopy(renderer, tex, NULL, &rect);
}

/*! \brief      Sets a brick's alive field to 0 signifying it is dead
*/
void Brick::KillBrick()
{
    alive = 0;
}
