#include "Brick.hpp"
#include <SDL2/SDL.h>

void Brick::Draw(SDL_Renderer *renderer, SDL_Texture *tex)
{
    SDL_Rect rect;
    rect.x = static_cast<int>(x);
    rect.y = static_cast<int>(y);
    rect.w = static_cast<int>(w);
    rect.h = static_cast<int>(h);

    SDL_RenderCopy(renderer, tex, NULL, &rect);
}

void Brick::KillBrick()
{
    alive = 0;
}
