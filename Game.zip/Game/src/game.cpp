// ==================== Libraries ==================
#include <chrono>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <iostream>
#include <fstream>
#include <string>

// ==================== Header Files ==================

#include "Ball.hpp"
#include "Brick.hpp"
#include "Constants.hpp"
#include "Paddle.hpp"
#include "PlayerScore.hpp"
#include "ResourceManager.hpp"
#include "Vec2.hpp"

// ==================== Functions ==================

/*! \brief      Checks if the paddle has a collision with the ball and returns the contact and its type
* @param Ball const ball
* @param Paddle const paddle
* @return Contact 
*/
Contact CheckPaddleCollision(Ball const &ball, Paddle const &paddle)
{
	float ballLeft = ball.position.x;
	float ballRight = ball.position.x + BALL_WIDTH;
	float ballTop = ball.position.y;
	float ballBottom = ball.position.y + BALL_HEIGHT;

	float paddleLeft = paddle.position.x;
	float paddleRight = paddle.position.x + PADDLE_WIDTH;
	float paddleTop = paddle.position.y;
	float paddleBottom = paddle.position.y + PADDLE_HEIGHT;

	Contact contact{};

	if (ballLeft >= paddleRight)
	{
		return contact;
	}

	if (ballRight <= paddleLeft)
	{
		return contact;
	}

	if (ballTop >= paddleBottom)
	{
		return contact;
	}

	if (ballBottom <= paddleTop)
	{
		return contact;
	}

	float paddleRangeUpper = paddleRight - (2.0f * (PADDLE_WIDTH / 3.0f));
	float paddleRangeMiddle = paddleRight - (PADDLE_WIDTH / 3.0f);

	if ((ballLeft > paddleLeft) && (ballLeft < paddleRangeUpper))
	{
		contact.type = CollisionType::Left;
	}
	else if ((ballLeft > paddleRangeUpper) && (ballLeft < paddleRangeMiddle))
	{
		contact.type = CollisionType::Middle;
	}
	else
	{
		contact.type = CollisionType::Right;
	}

	return contact;
}

/*! \brief      Checks if the ball has a collision with the wall and returns the contact and its type
* @param Ball const ball
* @return Contact 
*/
Contact CheckWallCollision(Ball const &ball)
{
	float ballLeft = ball.position.x;
	float ballRight = ball.position.x + BALL_WIDTH;
	float ballTop = ball.position.y;
	float ballBottom = ball.position.y + BALL_HEIGHT;

	Contact contact{};

	if (ballLeft < 0.0f)
	{
		contact.type = CollisionType::Left;
		contact.penetration = ballLeft;
	}
	else if (ballRight > WINDOW_WIDTH)
	{

		contact.type = CollisionType::Right;
		contact.penetration = ballRight;
	}
	else if (ballTop < 0.0f)
	{
		contact.type = CollisionType::Top;
		contact.penetration = -ballTop;
	}
	else if (ballBottom > WINDOW_HEIGHT)
	{
		contact.type = CollisionType::Bottom;
	}

	return contact;
}

/*! \brief      Checks if the ball has a collision with the a brick and returns the contact and its type
* @param Ball const ball
* @param Brick bricks[]
* @return Contact 
*/
Contact CheckBrickCollision(Ball const &ball, Brick bricks[])
{
	float ballLeft = ball.position.x;
	float ballRight = ball.position.x + BALL_WIDTH;
	float ballTop = ball.position.y;
	float ballBottom = ball.position.y + BALL_HEIGHT;

	Contact contact{};
	for (int i = 0; i < 96; i++)
	{
		if (bricks[i].alive == 1)
		{
			// checks if ball falls along x-axis of brick
			if ((ballLeft >= bricks[i].x &&
				 ballLeft <= bricks[i].x2) ||
				(ballRight >= bricks[i].x &&
				 ballRight <= bricks[i].x2))
			{

				// ball hits top of brick
				if ((ballBottom >= bricks[i].y) && (ballBottom <= bricks[i].y + COLLISION_CUSHION))
				{
					bricks[i].KillBrick();
					contact.type = CollisionType::Top;
					return contact;
				}
				// ball hits bottom of brick

				if ((ballTop <= bricks[i].y2) && (ballTop <= bricks[i].y2 + COLLISION_CUSHION))
				{
					bricks[i].KillBrick();
					contact.type = CollisionType::Bottom;
					return contact;
				}
			}
			// checks if ball falls along y-axis along brick
			if ((ballTop >= bricks[i].y &&
				 ballTop <= bricks[i].y2) ||
				(ballBottom >= bricks[i].y &&
				 ballBottom <= bricks[i].y2))
			{
				// ball hits left of brick
				if ((ballRight >= bricks[i].x) && (ballRight <= bricks[i].x + COLLISION_CUSHION))
				{
					std::cout << "ball falls leftt of brick\n"
							  << std::endl;
					bricks[i].KillBrick();
					contact.type = CollisionType::Left;
					return contact;
				}
				// ball hits right of brick
				if ((ballLeft >= bricks[i].x2) && (ballLeft <= bricks[i].x + COLLISION_CUSHION))
				{
					std::cout << "ball falls right of brick\n"
							  << std::endl;
					bricks[i].KillBrick();
					contact.type = CollisionType::Right;
					return contact;
				}
			}
		}
	}
	return contact;
}

/*! \brief      Loads the level into a string array and sets settings 
* @param std::string filename
* @param std::string level
* @param std::string nextLevelFilePointer
* @param std::string fileArray[8]
*/
void LevelLoader(std::string filename, std::string *level, std::string *nextLevelFilePointer, std::string fileArray[8])
{
	std::ifstream settings(filename);

	settings >> *level;
	settings >> *nextLevelFilePointer;
	for (int i = 0; i < 8; i++)
	{
		settings >> fileArray[i];
	}
}

/*! \brief      Reads the level file in its array form and makes the bricks as the file directs 
* @param std::string fileArr[8] 
* @param  Brick brickArray[]
*/
void makeBricks(std::string fileArr[8], Brick brickArray[])
{
	int brickNum = 0;
	int x = 40;
	int y = 70;
	for (int row = 0; row < 8; row++)
	{
		for (int col = 0; col < 12; col++)
		{
			if (fileArr[row][col] == '1')
			{
				brickArray[brickNum].alive = 1;
			}
			else
			{
				brickArray[brickNum].alive = 0;
			}

			brickArray[brickNum].x = x;
			brickArray[brickNum].y = y;
			brickArray[brickNum].w = BRICK_WIDTH;
			brickArray[brickNum].h = BRICK_HEIGHT;
			brickArray[brickNum].x2 = x + BRICK_WIDTH;
			brickArray[brickNum].y2 = y + BRICK_HEIGHT;

			brickNum++;
			x = x + BRICK_WIDTH;
		}
		x = 40;
		y = y + BRICK_HEIGHT + 5;
	}
}

// ==================== Main ==================

ResourceManager *ResourceManager::instance = 0;
ResourceManager *resourceManager = resourceManager->getInstance();

int main()
{
	// Initialize SDL components
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
	TTF_Init();
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0)
	{
		std::cout << "Error" << Mix_GetError() << std::endl;
	}

	SDL_Window *window = SDL_CreateWindow("Breakout", 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
	SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, 0);

	// Initialize the font
	TTF_Font *scoreFont = TTF_OpenFont("Assets/DejaVuSansMono.ttf", 30);
	TTF_Font *loseWinFont = TTF_OpenFont("Assets/DejaVuSansMono.ttf", 100);

	// Text for pregame language selection
	char select[] = "Select a Language";
	char spanish[] = "Spanish (s)";
	char english[] = "English (e)";
	SDL_Surface *selMessage = TTF_RenderText_Solid(scoreFont, select, {97, 192, 191, 0xFF});
	SDL_Texture *selectMessage = SDL_CreateTextureFromSurface(renderer, selMessage);
	SDL_Surface *spanMessage = TTF_RenderText_Solid(scoreFont, spanish, {97, 192, 191, 0xFF});
	SDL_Texture *spanishMessage = SDL_CreateTextureFromSurface(renderer, spanMessage);
	SDL_Surface *engMessage = TTF_RenderText_Solid(scoreFont, english, {97, 192, 191, 0xFF});
	SDL_Texture *englishMessage = SDL_CreateTextureFromSurface(renderer, engMessage);
	SDL_Rect Select_rect;
	Select_rect.x = 340;
	Select_rect.y = 260;
	Select_rect.w = 500;
	Select_rect.h = 100;
	SDL_Rect Spanish_rect;
	Spanish_rect.x = 440;
	Spanish_rect.y = 360;
	Spanish_rect.w = 300;
	Spanish_rect.h = 100;
	SDL_Rect English_rect;
	English_rect.x = 440;
	English_rect.y = 460;
	English_rect.w = 300;
	English_rect.h = 100;

	// Text for game
	// score, win, lose
	std::string scoreHead = "Score:";
	std::string win = "Win:)";
	std::string lose = "Lose:(";
	SDL_Color White = {255, 255, 255};
	SDL_Surface *losingMessage = TTF_RenderText_Solid(loseWinFont, lose.c_str(), White);
	SDL_Texture *lossMessage = SDL_CreateTextureFromSurface(renderer, losingMessage);
	SDL_Surface *winningMessage = TTF_RenderText_Solid(loseWinFont, win.c_str(), White);
	SDL_Texture *winMessage = SDL_CreateTextureFromSurface(renderer, winningMessage);
	SDL_Surface *scoreMessage = TTF_RenderText_Solid(scoreFont, scoreHead.c_str(), {147, 0, 119, 0xFF});
	SDL_Texture *scoreHeaderMessage = SDL_CreateTextureFromSurface(renderer, scoreMessage);
	SDL_Rect Message_rect;
	Message_rect.x = 340;
	Message_rect.y = 260;
	Message_rect.w = 500;
	Message_rect.h = 200;
	SDL_Rect Score_rect;
	Score_rect.x = 5;
	Score_rect.y = 15;
	Score_rect.w = 80;
	Score_rect.h = 40;

	//Text for level
	std::string levelHead = "Level:";
	std::string level = "1";
	std::string *levelPointer = &level;
	SDL_Surface *levelMessage = TTF_RenderText_Solid(scoreFont, levelHead.c_str(), {147, 0, 119, 0xFF});
	SDL_Texture *levelHeaderMessage = SDL_CreateTextureFromSurface(renderer, levelMessage);
	SDL_Surface *levelNumMessage = TTF_RenderText_Solid(scoreFont, level.c_str(), {147, 0, 119, 0xFF});
	SDL_Texture *levelNumberMessage = SDL_CreateTextureFromSurface(renderer, levelNumMessage);
	SDL_Rect LevelHead_rect;
	LevelHead_rect.x = 190;
	LevelHead_rect.y = 15;
	LevelHead_rect.w = 80;
	LevelHead_rect.h = 40;
	SDL_Rect Level_rect;
	Level_rect.x = 283;
	Level_rect.y = 20;
	Level_rect.w = 20;
	Level_rect.h = 35;

	// Initialize sound effects
	Mix_Music *bgn = Mix_LoadMUS("Assets/DayInParis.wav");
	Mix_Chunk *brickHitSound = Mix_LoadWAV("Assets/brickHit.wav");
	Mix_Chunk *paddleHitSound = Mix_LoadWAV("Assets/paddleHit.wav");
	Mix_Chunk *wallHitSound = Mix_LoadWAV("Assets/wallHit.wav");

	// Load images into Resource Manager
	resourceManager->init("Assets/heart.png", renderer);
	resourceManager->init("Assets/brick.png", renderer);

	// get brick texture
	SDL_Texture *brick = resourceManager->getTexture("Assets/brick.png");

	// heart lives image
	SDL_Texture *heart = resourceManager->getTexture("Assets/heart.png");
	SDL_Rect rect1;
	rect1.x = 1080;
	rect1.y = 0;
	rect1.w = 100;
	rect1.h = 100;

	SDL_Rect rect2;
	rect2.x = 1130;
	rect2.y = 0;
	rect2.w = 100;
	rect2.h = 100;

	SDL_Rect rect3;
	rect3.x = 1180;
	rect3.y = 0;
	rect3.w = 100;
	rect3.h = 100;

	// Game logic
	{
		bool running = true;
		float dt = 0.0f;
		bool buttons[4] = {};
		int player = 0;
		int lives = 3;
		int maxScore = 48;
		int score = 0;
		int fps = 60;
		int desiredDelta = 1000 / fps;
		int languageSelect = 0;

		// Set the draw color to be purple
		SDL_SetRenderDrawColor(renderer, 147, 0, 119, 0xFF);
		// Create the player score text fields
		PlayerScore playerScoreText(Vec2(110, 20), renderer, scoreFont);

		// Create the ball
		Ball ball(
			Vec2((WINDOW_WIDTH / 2.0f) - (BALL_WIDTH / 2.0f),
				 (WINDOW_HEIGHT - (PADDLE_WIDTH / 2.0f) - BALL_HEIGHT)),
			Vec2(0.0f, -BALL_SPEED));

		// Create the paddle
		Paddle paddle(
			Vec2((WINDOW_WIDTH / 2.0f) - (PADDLE_WIDTH / 2.0f),
				 (WINDOW_HEIGHT - (PADDLE_WIDTH / 2.0f))),
			Vec2(0.0f, 0.0f));

		// Load the level make brick array
		std::string fileArray[8];
		Brick brickArray[96];
		std::string nextLevelFile;
		std::string *nextLevelFilePointer = &nextLevelFile;

		LevelLoader("Assets/levelOne.txt", levelPointer, nextLevelFilePointer, fileArray);
		levelNumMessage = TTF_RenderText_Solid(scoreFont, level.c_str(), {147, 0, 119, 0xFF});
		levelNumberMessage = SDL_CreateTextureFromSurface(renderer, levelNumMessage);

		makeBricks(fileArray, brickArray);

		// Select language before game starts
		while (languageSelect == 0)
		{
			// Plays Music
			if (!Mix_PlayingMusic())
			{
				Mix_PlayMusic(bgn, -1);
			}
			// set screen to show language selections
			SDL_SetRenderDrawColor(renderer, 255, 207, 223, 0xFF);
			SDL_RenderClear(renderer);
			SDL_RenderCopy(renderer, selectMessage, NULL, &Select_rect);
			SDL_RenderCopy(renderer, spanishMessage, NULL, &Spanish_rect);
			SDL_RenderCopy(renderer, englishMessage, NULL, &English_rect);
			SDL_RenderPresent(renderer);
			SDL_Event event;
			while (SDL_PollEvent(&event))
			{
				if (event.key.keysym.sym == SDLK_s)
				{
					//spanish
					std::ifstream settings("Assets/spanish.txt");

					settings >> scoreHead;
					settings >> win;
					settings >> lose;
					settings >> levelHead;

					losingMessage = TTF_RenderText_Solid(loseWinFont, lose.c_str(), White);
					lossMessage = SDL_CreateTextureFromSurface(renderer, losingMessage);
					winningMessage = TTF_RenderText_Solid(loseWinFont, win.c_str(), White);
					winMessage = SDL_CreateTextureFromSurface(renderer, winningMessage);
					scoreMessage = TTF_RenderText_Solid(scoreFont, scoreHead.c_str(), {147, 0, 119, 0xFF});
					scoreHeaderMessage = SDL_CreateTextureFromSurface(renderer, scoreMessage);
					levelMessage = TTF_RenderText_Solid(scoreFont, levelHead.c_str(), {147, 0, 119, 0xFF});
					levelHeaderMessage = SDL_CreateTextureFromSurface(renderer, levelMessage);
					languageSelect = 1;
				}
				else if (event.key.keysym.sym == SDLK_e)
				{
					//english
					std::ifstream settings("Assets/english.txt");

					settings >> scoreHead;
					settings >> win;
					settings >> lose;
					settings >> levelHead;

					losingMessage = TTF_RenderText_Solid(loseWinFont, lose.c_str(), White);
					lossMessage = SDL_CreateTextureFromSurface(renderer, losingMessage);
					winningMessage = TTF_RenderText_Solid(loseWinFont, win.c_str(), White);
					winMessage = SDL_CreateTextureFromSurface(renderer, winningMessage);
					scoreMessage = TTF_RenderText_Solid(scoreFont, scoreHead.c_str(), {147, 0, 119, 0xFF});
					scoreHeaderMessage = SDL_CreateTextureFromSurface(renderer, scoreMessage);
					scoreMessage = TTF_RenderText_Solid(scoreFont, scoreHead.c_str(), {147, 0, 119, 0xFF});
					scoreHeaderMessage = SDL_CreateTextureFromSurface(renderer, scoreMessage);
					levelMessage = TTF_RenderText_Solid(scoreFont, levelHead.c_str(), {147, 0, 119, 0xFF});
					levelHeaderMessage = SDL_CreateTextureFromSurface(renderer, levelMessage);
					languageSelect = 1;
				}
				else if (event.key.keysym.sym == SDLK_q)
				{
					running = false;
					languageSelect = 1;
				}
			}
		}
		// game starts running
		while (running)
		{

			int startLoop = SDL_GetTicks();
			auto startTime = std::chrono::high_resolution_clock::now();

			SDL_Event event;
			while (SDL_PollEvent(&event))
			{
				if (event.type == SDL_QUIT)
				{
					running = false;
				}
				else if (event.type == SDL_KEYDOWN)
				{
					if (event.key.keysym.sym == SDLK_ESCAPE)
					{
						running = false;
					}
					else if (event.key.keysym.sym == SDLK_q)
					{
						running = false;
					}
					else if (event.key.keysym.sym == SDLK_a)
					{
						buttons[Buttons::PaddleLeft] = true;
					}
					else if (event.key.keysym.sym == SDLK_d)
					{
						buttons[Buttons::PaddleRight] = true;
					}
					else if (event.key.keysym.sym == SDLK_s)
					{
						//spanish
						std::ifstream settings("Assets/spanish.txt");

						settings >> scoreHead;
						settings >> win;
						settings >> lose;
						settings >> levelHead;

						losingMessage = TTF_RenderText_Solid(loseWinFont, lose.c_str(), White);
						lossMessage = SDL_CreateTextureFromSurface(renderer, losingMessage);
						winningMessage = TTF_RenderText_Solid(loseWinFont, win.c_str(), White);
						winMessage = SDL_CreateTextureFromSurface(renderer, winningMessage);
						scoreMessage = TTF_RenderText_Solid(scoreFont, scoreHead.c_str(), {147, 0, 119, 0xFF});
						scoreHeaderMessage = SDL_CreateTextureFromSurface(renderer, scoreMessage);
						levelMessage = TTF_RenderText_Solid(scoreFont, levelHead.c_str(), {147, 0, 119, 0xFF});
						levelHeaderMessage = SDL_CreateTextureFromSurface(renderer, levelMessage);
					}
					else if (event.key.keysym.sym == SDLK_e)
					{
						//english
						std::ifstream settings("Assets/english.txt");

						settings >> scoreHead;
						settings >> win;
						settings >> lose;
						settings >> levelHead;

						losingMessage = TTF_RenderText_Solid(loseWinFont, lose.c_str(), White);
						lossMessage = SDL_CreateTextureFromSurface(renderer, losingMessage);
						winningMessage = TTF_RenderText_Solid(loseWinFont, win.c_str(), White);
						winMessage = SDL_CreateTextureFromSurface(renderer, winningMessage);
						scoreMessage = TTF_RenderText_Solid(scoreFont, scoreHead.c_str(), {147, 0, 119, 0xFF});
						scoreHeaderMessage = SDL_CreateTextureFromSurface(renderer, scoreMessage);
						levelMessage = TTF_RenderText_Solid(scoreFont, levelHead.c_str(), {147, 0, 119, 0xFF});
						levelHeaderMessage = SDL_CreateTextureFromSurface(renderer, levelMessage);
					}
					else if (event.key.keysym.sym == SDLK_LEFT)
					{
						buttons[Buttons::PaddleLeft] = true;
					}
					else if (event.key.keysym.sym == SDLK_RIGHT)
					{
						buttons[Buttons::PaddleRight] = true;
					}
				}
				else if (event.type == SDL_KEYUP)
				{
					if (event.key.keysym.sym == SDLK_a)
					{
						buttons[Buttons::PaddleLeft] = false;
					}
					else if (event.key.keysym.sym == SDLK_d)
					{
						buttons[Buttons::PaddleRight] = false;
					}
					else if (event.key.keysym.sym == SDLK_LEFT)
					{
						buttons[Buttons::PaddleLeft] = false;
					}
					else if (event.key.keysym.sym == SDLK_RIGHT)
					{
						buttons[Buttons::PaddleRight] = false;
					}
				}
			}
			if (buttons[Buttons::PaddleLeft])
			{
				paddle.velocity.x = -PADDLE_SPEED;
			}
			else if (buttons[Buttons::PaddleRight])
			{
				paddle.velocity.x = PADDLE_SPEED;
			}
			else
			{
				paddle.velocity.x = 0.0f;
			}

			// Update the paddle positions
			paddle.Update(dt);

			// Update the ball position
			ball.Update(dt);

			// Check collisions
			if (Contact contact = CheckPaddleCollision(ball, paddle);
				contact.type != CollisionType::None)
			{
				ball.CollideWithPaddle(contact);
				Mix_PlayChannel(-1, paddleHitSound, 0);
			}
			else if (contact = CheckWallCollision(ball);
					 contact.type != CollisionType::None)
			{
				ball.CollideWithWall(contact);
				Mix_PlayChannel(-1, wallHitSound, 0);
				if (contact.type == CollisionType::Bottom)
				{
					--lives;
					if (lives == 0)
					{
						// set screen to red and show lose message
						SDL_SetRenderDrawColor(renderer, 247, 56, 89, 0xFF);
						SDL_RenderClear(renderer);
						SDL_RenderCopy(renderer, lossMessage, NULL, &Message_rect);
						SDL_RenderPresent(renderer);

						SDL_Delay(5000);
						running = false;
					}
				}
			}
			else if (contact = CheckBrickCollision(ball, brickArray);
					 contact.type != CollisionType::None)
			{
				ball.CollideWithBrick(contact);
				Mix_PlayChannel(-1, brickHitSound, 0);
				++score;
				playerScoreText.SetScore(score);
				// if user wins show win message
				if (score == maxScore)
				{
					// set screen to green
					SDL_SetRenderDrawColor(renderer, 31, 171, 137, 0xFF);
					SDL_RenderClear(renderer);
					SDL_RenderCopy(renderer, winMessage, NULL, &Message_rect);
					SDL_RenderPresent(renderer);

					SDL_Delay(3000);
					// if nextLevelFileName != null
					// load level
					std::string nullCheck = "null";
					if (nextLevelFile.compare(nullCheck) != 0)
					{
						LevelLoader(nextLevelFile, levelPointer, nextLevelFilePointer, fileArray);
						levelNumMessage = TTF_RenderText_Solid(scoreFont, level.c_str(), {147, 0, 119, 0xFF});
						levelNumberMessage = SDL_CreateTextureFromSurface(renderer, levelNumMessage);
						makeBricks(fileArray, brickArray);
						lives = 3;
						score = 0;
						playerScoreText.SetScore(score);
					}
					else
					{
						running = false;
					}
				}
			}

			// Clear the window to pink
			SDL_SetRenderDrawColor(renderer, 255, 213, 229, 0xFF);
			SDL_RenderClear(renderer);

			// Set the draw color to be green
			SDL_SetRenderDrawColor(renderer, 31, 171, 137, 0xFF);

			// Draw the ball
			ball.Draw(renderer);

			// Set the draw color to be purple
			SDL_SetRenderDrawColor(renderer, 152, 150, 241, 0xFF);

			// Draw the paddle
			paddle.Draw(renderer);

			// Draw bricks
			for (int i = 0; i < 96; i++)
			{
				if (brickArray[i].alive == 1)
				{
					brickArray[i].Draw(renderer, brick);
				}
			}

			// Display the score and text "Score:"
			playerScoreText.Draw();
			SDL_RenderCopy(renderer, scoreHeaderMessage, NULL, &Score_rect);
			SDL_RenderCopy(renderer, levelHeaderMessage, NULL, &LevelHead_rect);
			SDL_RenderCopy(renderer, levelNumberMessage, NULL, &Level_rect);

			// Copying the texture on to the window using renderer and rectangle
			// Heart
			if (lives == 3)
			{
				SDL_RenderCopy(renderer, heart, NULL, &rect1);
				SDL_RenderCopy(renderer, heart, NULL, &rect2);
				SDL_RenderCopy(renderer, heart, NULL, &rect3);
			}
			else if (lives == 2)
			{
				SDL_RenderCopy(renderer, heart, NULL, &rect2);
				SDL_RenderCopy(renderer, heart, NULL, &rect3);
			}
			else if (lives == 1)
			{
				SDL_RenderCopy(renderer, heart, NULL, &rect3);
			}

			// Present the backbuffer
			SDL_RenderPresent(renderer);

			// Makes sure fps is 60

			int delta = SDL_GetTicks() - startLoop;
			if (delta < desiredDelta)
			{
				SDL_Delay(desiredDelta - delta);
			}

			// Calculate frame time
			auto stopTime = std::chrono::high_resolution_clock::now();
			dt = std::chrono::duration<float, std::chrono::milliseconds::period>(stopTime - startTime).count();
		}
	}

	// Cleanup
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	Mix_FreeMusic(bgn);
	Mix_FreeChunk(brickHitSound);
	Mix_FreeChunk(paddleHitSound);
	Mix_FreeChunk(wallHitSound);
	bgn = nullptr;
	TTF_CloseFont(scoreFont);
	Mix_Quit();
	TTF_Quit();
	SDL_Quit();

	return 0;
}